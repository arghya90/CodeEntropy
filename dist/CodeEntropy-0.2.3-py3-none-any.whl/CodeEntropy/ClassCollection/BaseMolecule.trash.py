"""
    def get_basis_1UA_links(self, arg_heavyAtomIndex, arg_isProtonated, arg_frame):
        """ There are two cases of finding the basis when a UA is linked with just one other UA. 
        It depends if the UA in question has protons or not.

        If arg_isProtonated = T, the axes are:
            0. Covalent bond with the linked UA
            1. Cross of covalent bond and the altitude from a heavy atom on the bonded-UA-H line
            2. This will be cross of 0 and 1. 

            >>> (These allows for only 2 DOF ideally but i am allowing for a thord one which should have very small torque and MOI).

        If arg_isProtonated = F, 
            there should be no rotational DOF
            assign arbitrary orthonormal bases

        Return a basis with axes in rows and the last row is the origin"""
        # Utils.printflush('1 link')

        #check first
        assert(self.isHydrogenArray[arg_heavyAtomIndex] == 0 and len(self.bondedHeavyAtomTable[arg_heavyAtomIndex]) == 1)

        # initialize
        basis = nmp.zeros((4,3))

        #heavy atom position
        r1 = self.hostDataContainer._labCoords[arg_frame][arg_heavyAtomIndex]

        # index of the covalenetly bonded heavy atom
        linkedHeavyAtomIndex = [iAtom for iPriority, iAtom in self.bondedHeavyAtomTable[arg_heavyAtomIndex].list_in_order()]
        
        # second heavy atom
        r2 = self.hostDataContainer._labCoords[arg_frame][linkedHeavyAtomIndex[0]]

        if arg_isProtonated:
            #check first: make sure it has 1 or more H            
            assert(len(self.bondedHydrogenTable[arg_heavyAtomIndex]) != 0  )

            # bonded H
            linkedHydrogenAtomIndex = [iAtom for iPriority, iAtom in self.bondedHydrogenTable[arg_heavyAtomIndex].list_in_order()]
            
            # resultant of all hydrogen positions
            rH = nmp.zeros((3))
            for j in range(3):
                rH[j] = nmp.mean(nmp.asarray([self.hostDataContainer._labCoords[arg_frame][iH][j] for iH in linkedHydrogenAtomIndex]))
            
            #axis0
            axis0 = r2 - r1
            basis[0,:] = axis0/nmp.linalg.norm(axis0)

            #axis 1
            axis1 = GeometricFunctions.get_altitude(arg_lineEndPoint1 = r2, arg_lineEndPoint2 = rH, arg_sourcePoint = r1)
            #     r1 
            #  /  |  \
            # r2-----rH1 

            # axis1 = nmp.cross(r2 - r1, axis1)
            axis1 = CustomFunctions.cross_product(r2 - r1, axis1)
            basis[1,:] = axis1/nmp.linalg.norm(axis1)


            #axis2 (zero)
            # axis2 = nmp.cross(basis[0,:], basis[1,:])
            axis2 = CustomFunctions.cross_product(basis[0,:], basis[1,:])
            basis[2,:] = axis2/nmp.linalg.norm(axis2)


        else:
            #check first: there shouldnt be any H and basis is all 0
            assert(len(self.bondedHydrogenTable[arg_heavyAtomIndex]) == 0)

            #axis0
            axis0 = r2 - r1
            basis[0,:] = axis0/nmp.linalg.norm(axis0)

            # axis1
            # choose an arbitrary point in space and treat it is a vertex of a triangle formed by r1, r2 and itself
            # altitude from that point on the bond will be the axis
            rRandom = nmp.random.random((3))
            axis1 = GeometricFunctions.get_altitude(arg_lineEndPoint1 = r2, arg_lineEndPoint2 = r1, arg_sourcePoint = rRandom)
            #  r1--------- 
            #  |  \
            #  |---rRandom
            #  |  /
            #  r2 
            basis[1,:] = axis1/nmp.linalg.norm(axis1)

            #axis2 (zero)
            # axis2 = nmp.cross(basis[0,:], basis[1,:])
            axis2 = CustomFunctions.cross_product(basis[0,:], basis[1,:])
            basis[2,:] = axis2/nmp.linalg.norm(axis2)


        # center is the corrdinate of the UA in question
        basis[-1,] = r1

        return basis

#END

    def get_basis_2UA_links (self, arg_heavyAtomIndex, arg_isProtonated, arg_frame):
        """ The basis in this case does not depend on the state of protonation of the heavy atom in question.

        The axes are:
            0. along the average of the two covalent bonds
            1. cross of altitude from arg_heavyAtomIndex on axis 0 and axis 0
            3. 0

        Return a basis with axes in rows and the last row is the origin"""
        # Utils.printflush('2 links')
        # check first
        assert(self.isHydrogenArray[arg_heavyAtomIndex] == 0 and len(self.bondedHeavyAtomTable[arg_heavyAtomIndex]) == 2)

        # initialize
        basis = nmp.zeros((4,3))


        # index of the covalenetly bonded atoms
        linkedHeavyAtomIndex = [iAtom for iPriority, iAtom in self.bondedHeavyAtomTable[arg_heavyAtomIndex].list_in_order()]
        
        # points
        r1 = self.hostDataContainer._labCoords[arg_frame][arg_heavyAtomIndex]
        r2 = self.hostDataContainer._labCoords[arg_frame][linkedHeavyAtomIndex[0]]
        r3 = self.hostDataContainer._labCoords[arg_frame][linkedHeavyAtomIndex[1]]

        # axis 0
        # along the line joining its bonded heavy atoms
        # along the average of bonds with 2 and 3
        axis0 = (r2 + r3)/2
        axis0 = axis0 - r1
        basis[0,:] = axis0/nmp.linalg.norm(axis0)

        # axis 1
        # altitude of r2 on axis 0 
        axis1 = GeometricFunctions.get_altitude(arg_lineEndPoint1 = r1, arg_lineEndPoint2 = r1 + axis0, arg_sourcePoint = r2)
        #     r1------ 
        #  /  |  \
        # r2-----r3 
        #     |
        #     |

        # axis1 = nmp.cross(r32, axis1)
        basis[1,:] = axis1/nmp.linalg.norm(axis1)

        #axis2 (zero)
        # axis2 = nmp.cross(basis[0,:], basis[1,:])
        axis2 = CustomFunctions.cross_product(basis[0,:], basis[1,:])
        basis[2,:] = axis2/nmp.linalg.norm(axis2)

        # center is the corrdinate of the UA in question
        basis[-1,] = r1

        return basis

#END

    def get_basis_3UA_links (self, arg_heavyAtomIndex, arg_isProtonated, arg_frame):
        

        """ The basis does not depend on the number of hydrogens on the heavy atom.

        The axes are:
            0. average of all the three vectors.
            1. altitude of the avg of bonds with 2 and 3 on axis 0
            2. Cross of 1,2
        Return a basis with axes in rows and the last row is the origin"""

        # Utils.printflush('3 links')
        #check first
        assert(self.isHydrogenArray[arg_heavyAtomIndex] == 0 and len(self.bondedHeavyAtomTable[arg_heavyAtomIndex])== 3)

        # initialize
        basis = nmp.zeros((4,3))


        # index of the covalenetly bonded Heavy atom
        linkedHeavyAtomIndex = [iAtom for iPriority, iAtom in self.bondedHeavyAtomTable[arg_heavyAtomIndex].list_in_order()]
        # linkedHydrogenAtomIndex = [iAtom for iPriority, iAtom in self.bondedHydrogenTable[arg_heavyAtomIndex].list_in_order()]

        # points
        r1 = self.hostDataContainer._labCoords[arg_frame][arg_heavyAtomIndex]
        r2 = self.hostDataContainer._labCoords[arg_frame][linkedHeavyAtomIndex[0]]
        r3 = self.hostDataContainer._labCoords[arg_frame][linkedHeavyAtomIndex[1]]
        r4 = self.hostDataContainer._labCoords[arg_frame][linkedHeavyAtomIndex[2]]
        # rH = self.hostDataContainer._labCoords[arg_frame][linkedHydrogenAtomIndex[0]] #take the first one

        # axis0 (average of three covalent bonds)
        axis0 = (r2 + r3 + r4)/3
        axis0 = axis0 - r1
        basis[0,] = axis0/nmp.linalg.norm(axis0)

        # axis1 : 
        # the altitude from avg of covalent bonds with 2 and 3 on axis 0
        rAvg = (r2 + r3)/2
        axis1 = GeometricFunctions.get_altitude(arg_lineEndPoint1 = r1, arg_lineEndPoint2 = r1 + axis0, arg_sourcePoint = rAvg)
        basis[1,] = axis1/nmp.linalg.norm(axis1)

        #axis2
        # axis2 = nmp.cross(basis[0,:], basis[1,:])
        axis2 = CustomFunctions.cross_product(basis[0,:], basis[1,:])
        basis[2,:] = axis2/nmp.linalg.norm(axis2)


        # center is the corrdinate of the UA in question
        basis[-1,] = r1

        return basis

    #END
"""