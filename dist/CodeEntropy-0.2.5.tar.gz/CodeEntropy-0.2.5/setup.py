#!/usr/bin/env python

from setuptools import setup
from setuptools import find_packages

# long descriptor of the package
with open("README.md" , 'r') as fin:
	long_desc = fin.read()


setup(
	## METADATA ##
	name = 'CodeEntropy', 
	author = 'Arghya \"Argo\" Chakravorty', 
	version="0.2.5",
	author_email = 'arghyac@umich.edu',
	url="https://github.com/arghya90/CodeEntropy",

	## DESCRIPTORS ##
	description = 'A python package of tools of computing entropy of macromolecular systems from the forces sampled in a MD simulation.',
	long_description = long_desc,
	long_description_content_type = "text/markdown",

	## OPTIONS ##
	packages = find_packages('src'),
	package_dir = {'' : 'src'},

	## REQUIREMENTS ##
	classifiers = ['Programming Language :: Python :: 3.6',
	               'Intended Audience :: Users'],

	# can be run as a zip
	zip_safe = False,

	# scripts for creating executables
	scripts = ['src/CodeEntropy/mcc_gromacs.py', \
	           'src/CodeEntropy/mcc_charmm.py']

)
