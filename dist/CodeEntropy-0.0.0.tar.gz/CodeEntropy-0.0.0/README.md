# CodeEntropy

CodeEntropy is a python package and a collection of scripts 
that can be used to compute entropy using the multiscale-cell-correlation (MCC) 
theory and force/torque covariance methods. 
The package has can be used to read coordinate and force trajectories from 
two popular MD packages, GROMACS and CHARMM. 

