import sys, os
import numpy as nmp

from CodeEntropy.ClassCollection import BeadClasses as BC
from CodeEntropy.ClassCollection import ConformationEntity as CONF
from CodeEntropy.ClassCollection import ModeClasses
from CodeEntropy.FunctionCollection import CustomFunctions as CF
from CodeEntropy.FunctionCollection import UnitsAndConversions as UAC
from CodeEntropy.FunctionCollection import GeometricFunctions as GF
from CodeEntropy.FunctionCollection import Utils
from CodeEntropy.IO import Writer

def compute_entropy_whole_molecule_level(arg_baseMolecule, 
                                         arg_hostDataContainer, 
										 arg_outFile, 
										 arg_moutFile,
										 arg_fScale,
										 arg_tScale,
										 arg_verbose):
	""" 
	Conpute the entropy at the whole molecule level. 
	Determining translation and rotation axes is part of the function.
	Returns void
	"""

	Utils.printflush('-'*60)
	Utils.printflush("{:^60}".format("Hierarchy level. --> Whole molecule <--"))
	Utils.printflush('-'*60)

	Utils.printOut(arg_outFile,'-'*60)
	Utils.printOut(arg_outFile,"{:^60}".format("Hierarchy level. --> Whole molecule <--"))
	Utils.printOut(arg_outFile,'-'*60)

	# Define a bead collection at this level
	wholeMoleculeSystem = BC.BeadCollection("whole_mol_bead", arg_hostDataContainer)

	# number of frames
	numFrames = len(arg_hostDataContainer.trajSnapshots)

	# define a bead representing the whole molecule
	wholeProteinBead = BC.Bead(arg_atomList=arg_baseMolecule.atomIndexArray, \
							arg_numFrames=numFrames, \
							arg_hostDataContainer = arg_hostDataContainer,\
							arg_beadName = "WMOL",
							arg_beadResi = 0,
							arg_beadResn = "WMOL",
							arg_beadChid = "X")

	# add the bead to the bead colleciton
	wholeMoleculeSystem.listOfBeads = []
	wholeMoleculeSystem.listOfBeads.append(wholeProteinBead)
	Utils.printflush("Total number of beads at the whole molecule level = {}"\
	              .format(len(wholeMoleculeSystem.listOfBeads)))
	Utils.printOut(arg_outFile,"Total number of beads at the whole molecule level = {}"\
	            .format(len(wholeMoleculeSystem.listOfBeads)))

	# reset weighted vectors for each bead and
	# and assign a representative position
	for iBead in wholeMoleculeSystem.listOfBeads:
		iBead.reset_totalWeightedVectors( (numFrames,3) )
		iBead.position = iBead.get_center_of_mass_lab(0)

	# reseting all the F-T combo matrices to zero
	wholeMoleculeSystem.reinitialize_matrices()

	# setup translational and rotational axes
	Utils.printflush("Assigning Translation and Rotation Axes @ whole molecule level->", end = ' ' )
	# Use Princ. Axes COOR SYS.
	# USE whole molecule principal axes COOR SYS for each atom
	for iFrame in range(numFrames):
		selMOI, selAxes = arg_baseMolecule\
						  .get_principal_axes(arg_atomList = wholeProteinBead.atomList,\
						                      arg_frame = iFrame, arg_sorted=False)
		selCOM = arg_baseMolecule\
				 .get_center_of_mass(arg_atomList = wholeProteinBead.atomList, \
				 	                 arg_frame = iFrame)
		arg_hostDataContainer.translationAxesArray[iFrame,:,:] = nmp.vstack((selAxes.T, selCOM))
		arg_hostDataContainer.rotationAxesArray[iFrame,:,:] = nmp.vstack((selAxes.T, selCOM))
	Utils.printflush("Done")
	

	# update local coordinates
	Utils.printflush("Updating Local coordinates->",end = ' ')
	arg_hostDataContainer.update_localCoords_of_all_atoms(arg_type="R")
	Utils.printflush('Done')

	# update local forces
	Utils.printflush("Updating Local forces->", end = ' ' )
	arg_hostDataContainer.update_localForces_of_all_atoms(arg_type="T")
	Utils.printflush('Done')

	#update torques in the arg_hostDataContainer
	Utils.printflush("Updating Local torques->", end = ' ')
	for iFrame in range(numFrames):
		for iAtom in arg_baseMolecule.atomIndexArray:
			coords_i = arg_hostDataContainer.localCoords[iFrame, iAtom]
			forces_i = arg_hostDataContainer.localForces[iFrame, iAtom]
			# arg_hostDataContainer.localTorques[iFrame,iAtom,:] = nmp.cross(coords_i,forces_i)
			arg_hostDataContainer.localTorques[iFrame,iAtom,:] = CF.cross_product(coords_i,forces_i)

		# mass weighting the forces and torques
		for iBead in wholeMoleculeSystem.listOfBeads:

			# mass weighting the forces for each bead (iBead) in each direction (j) 
			#inertia weighting the torques for each bead (iBead) in each direction (j)

			# define local basis as the rotationalAxes of the first atom in the atomList of iBead 
			# doesnt matter because they all have the same R and T axes
			iLocalBasis = arg_hostDataContainer.rotationAxesArray[iFrame][iBead.atomList[0]]

			#get the moment of inertia tensor for ibead in thid local basis
			beadMOITensor = iBead.get_moment_of_inertia_tensor_local(arg_localBasis = iLocalBasis, arg_frame = iFrame)

			# get total torque and force in each direction and weight them by √beadMOITensor[jj]
			for j in range(3):
				iBead.totalWeightedForces[iFrame,j] = nmp.sum(nmp.asarray([arg_hostDataContainer.localForces[iFrame,aid,j] for aid in iBead.atomList]))
				iBead.totalWeightedTorques[iFrame,j] = nmp.sum(nmp.asarray([arg_hostDataContainer.localTorques[iFrame,aid,j] for aid in iBead.atomList]))

				if nmp.isclose(iBead.totalWeightedTorques[iFrame,j], 0.0):
					# then the beadMOITensor[j,j] must be close to 0 as well (machine precision wise)
					# ensure that
					assert(nmp.isclose(beadMOITensor[j,j] , 0.0))
				else:
					iBead.totalWeightedTorques[iFrame,j] /= nmp.sqrt(beadMOITensor[j,j])

				# the above does nto apply for force
				iBead.totalWeightedForces[iFrame,j] /= nmp.sqrt(iBead.get_total_mass())

	Utils.printflush('Done')

	# now fill in the matrices
	Utils.printflush("Updating the submatrices ... ")
	wholeMoleculeSystem.update_subMatrix(arg_pairString="FF",arg_verbose=arg_verbose)
	wholeMoleculeSystem.update_subMatrix(arg_pairString="TT",arg_verbose=arg_verbose)
	Utils.printflush('Done')

	#make quadrant from subMatrices
	# FF and TT quadrants must be symmetric
	Utils.printflush("Generating Quadrants->",end = ' ')
	ffQuadrant = wholeMoleculeSystem.generate_quadrant(arg_pairString="FF",arg_filterZeros=1)
	ttQuadrant = wholeMoleculeSystem.generate_quadrant(arg_pairString="TT",arg_filterZeros=1)

	# scale forces/torques of these quadrants
	ffQuadrant = nmp.multiply(arg_fScale**2, ffQuadrant)
	ttQuadrant = nmp.multiply(arg_tScale**2, ttQuadrant)

	# print matrices
	Writer.write_a_matrix(arg_matrix = ffQuadrant, arg_descriptor = "FF COV AT WHOLE MOLECULE LEVEL", arg_outFile = arg_moutFile)
	Writer.write_a_matrix(arg_matrix = ttQuadrant, arg_descriptor = "TT COV AT WHOLE MOLECULE LEVEL", arg_outFile = arg_moutFile)
	Utils.printflush("Done")

	# remove any row or column with zero axis
	# this could have been done while generating quadrants. Can be merged if wished for
	# ffQuadrant = wholeMoleculeSystem.filter_zero_rows_columns(ffQuadrant)
	# ttQuadrant = wholeMoleculeSystem.filter_zero_rows_columns(ttQuadrant)


	#diagnolaize
	Utils.printflush("Diagonalizing->", end = ' ' )
	lambdasFF, eigVectorsFF  = Utils.diagonalize(ffQuadrant)	
	lambdasTT, eigVectorsTT  = Utils.diagonalize(ttQuadrant)
	Utils.printflush('Done')

	# since eigen values can be complex numbers but with imag parts very close to zero
	# use numpy's real_if_close with some tolerance to mask the imag parts
	# Utils.printflush('Checking the nature of eigen values and conditioning them ...', end = ' ')
	# tol = 1e+5
	# lambdasFF = nmp.real_if_close(lambdasFF/1e+5, tol= tol)
	# lambdasTT = nmp.real_if_close(lambdasTT/1e+5, tol= tol)
	# Utils.printflush('Done')

	# change to SI units
	Utils.printflush('Changing the units of eigen values to SI units->', end = ' ')
	lambdasFF = UAC.change_lambda_units(lambdasFF)
	lambdasTT = UAC.change_lambda_units(lambdasTT)
	Utils.printflush('Done')


	# Create a spectrum to store these modes for 
	# proper output and analyses.
	modeSpectraFF = [] 
	modeSpectraTT = []
	for midx, mcombo in enumerate(zip(lambdasFF, eigVectorsFF)):
		fflmb, evec = mcombo
		# compute mode frequencies
		# nu = sqrt(lambda/kT)*(1/2pi)
		# Units: 1/s
		mfreq = compute_frequency_from_lambda(fflmb)
		newMode = ModeClasses.Mode(arg_modeIdx = midx + 1, \
			arg_modeEval = fflmb, \
			arg_modeEvec = evec, \
			arg_modeFreq = mfreq)
		newMode.set_mode_length(mfreq)
		modeSpectraFF.append(newMode)

	for midx, mcombo in enumerate(zip(lambdasTT, eigVectorsTT)):
		ttlmb, evec = mcombo
		# compute mode frequencies
		# nu = sqrt(lambda/kT)*(1/2pi)
		# Units: 1/s
		mfreq = compute_frequency_from_lambda(ttlmb)
		newMode = ModeClasses.Mode(arg_modeIdx = midx + 1, \
			arg_modeEval = ttlmb, \
			arg_modeEvec = evec, \
			arg_modeFreq = mfreq)
		newMode.set_mode_length(mfreq)
		modeSpectraTT.append(newMode)

	# assign spectra to the bead collection 
	wholeMoleculeSystem.assign_attribute("modeSpectraFF", modeSpectraFF)
	wholeMoleculeSystem.assign_attribute("modeSpectraTT", modeSpectraTT)

	# sorting the spectrum
	Utils.printflush('Sorting spectrum in ascending order of frequencies->', end = ' ')
	wholeMoleculeSystem.modeSpectraFF = ModeClasses.sort_modes(wholeMoleculeSystem.modeSpectraFF)
	wholeMoleculeSystem.modeSpectraTT = ModeClasses.sort_modes(wholeMoleculeSystem.modeSpectraTT)
	Utils.printflush('Done')

	# Print modes
	outSpectraFF = "{}_FF_spectra.nmd".format(wholeMoleculeSystem.name)
	Writer.write_file(outSpectraFF)
	for ffmode in wholeMoleculeSystem.modeSpectraFF:
		Utils.printOut(outSpectraFF, "# *** {} {:.3f}".format(ffmode.modeIdx, ffmode.modeFreq/UAC.C_LIGHT))
		Utils.printOut(outSpectraFF, ffmode.get_mode_info())
		
	outSpectraTT = "{}_TT_spectra.nmd".format(wholeMoleculeSystem.name)
	Writer.write_file(outSpectraTT)
	for ttmode in wholeMoleculeSystem.modeSpectraTT:
		Utils.printOut(outSpectraTT, "# *** {} {:.3f}".format(ttmode.modeIdx, ttmode.modeFreq/UAC.C_LIGHT))
		Utils.printOut(outSpectraTT, ttmode.get_mode_info())

	# compute entropy
	entropyFF = [calculate_entropy_per_dof(m.modeFreq) for m in wholeMoleculeSystem.modeSpectraFF]
	entropyTT = [calculate_entropy_per_dof(m.modeFreq) for m in wholeMoleculeSystem.modeSpectraTT]

	# print final outputs
	Utils.printflush("Entropy values:")
	Utils.printflush('{:<40s} : {:.4f} J/mol/K'.format('FF Entropy (Whole mol level)',nmp.sum(entropyFF)))
	Utils.printOut(arg_outFile, '{:<40s} : {:.4f} J/mol/K'.format('FF Entropy (Whole mol level)',nmp.sum(entropyFF)))
	
	Utils.printflush('{:<40s} : {:.4f} J/mol/K'.format('TT Entropy (Whole mol level)',nmp.sum(entropyTT)))
	Utils.printOut(arg_outFile, '{:<40s} : {:.4f} J/mol/K'.format('TT Entropy (Whole mol level)',nmp.sum(entropyTT)))
	

	return 
#END


def compute_entropy_residue_level(arg_baseMolecule, 
                                  arg_hostDataContainer, 
								  arg_outFile, 
								  arg_moutFile,
								  arg_fScale,
								  arg_tScale,
								  arg_verbose):
	""" 
	Computes the entropy calculations at the residue level
	where each residue is treated as a separate bead.
	Determining translation and rotation axes is part of the 
	function. A common translation axes are used for all residues
	which is the principal axes of the whole molecule. The rotation
	axes are specific to each residue, in that it is the C-Ca-N axes. 
	"""

	Utils.printflush('-'*60)
	Utils.printflush("{:^60}".format("Hierarchy level. --> Residues <--"))
	Utils.printflush('-'*60)

	Utils.printOut(arg_outFile,'-'*60)
	Utils.printOut(arg_outFile,"{:^60}".format("Hierarchy level. --> Residues <--"))
	Utils.printOut(arg_outFile,'-'*60)
	
	# define a bead collection at this level
	residueSystem = BC.BeadCollection("res_bead",arg_hostDataContainer)

	# number of frames
	numFrames = len(arg_hostDataContainer.trajSnapshots)

	
	# define the residue beads and add
	residueSystem.listOfBeads= []

	for rid in range(arg_baseMolecule.numResidues):
		resLabel = "{}{}".format(arg_baseMolecule.resnameArray[rid], arg_baseMolecule.residArray[rid])
		atoms_in_rid = []
		iAtom_in_rid = int(arg_baseMolecule.residueHead[rid])
		while iAtom_in_rid != -1:
			# Utils.printflush(iAtom_in_rid)
			atoms_in_rid.append(iAtom_in_rid)
			iAtom_in_rid = int(arg_baseMolecule.atomArray[iAtom_in_rid])

		newBead = BC.Bead(arg_atomList = atoms_in_rid, \
					   arg_numFrames = numFrames, \
					   arg_hostDataContainer = arg_hostDataContainer,\
					   	arg_beadName = resLabel,
						arg_beadResi = arg_baseMolecule.residArray[rid],
						arg_beadResn = arg_baseMolecule.resnameArray[rid],
						arg_beadChid = "X" )
		residueSystem.listOfBeads.append(newBead)

	Utils.printflush("Total number of beads at the residue level = {}".format(len(residueSystem.listOfBeads)))

	# reset weighted vectors for each bead
	for iBead in residueSystem.listOfBeads:
		iBead.reset_totalWeightedVectors( (numFrames,3) )

	# reseting all the F-T combo matrices to zero
	residueSystem.reinitialize_matrices()

	# setup translation axes 
	arg_hostDataContainer.reset_translationAxesArray()
	Utils.printflush("Assigning Translation Axes @ residue level->", end = ' ')
	# Use Princ. Axes COOR SYS.
	for iFrame in range(numFrames):
		selMOI, selAxes = arg_baseMolecule\
		                  .get_principal_axes(arg_atomList = arg_baseMolecule.atomIndexArray, arg_frame = iFrame, arg_sorted=False)
		selCOM = arg_baseMolecule\
				 .get_center_of_mass(arg_atomList = arg_baseMolecule.atomIndexArray, arg_frame = iFrame)
		arg_hostDataContainer.translationAxesArray[iFrame,:,:] = nmp.vstack((selAxes.T, selCOM))
	Utils.printflush("Done")

	# setup rotational axes
	arg_hostDataContainer.reset_rotationAxesArray()
	Utils.printflush("Assigning Rotational Axes @ residue level->")
	# for each residue, set the rotational axes to the c-ca-N axes
	for rid in range(arg_baseMolecule.numResidues):
		atoms_in_rid = []
		iAtom_in_rid = int(arg_baseMolecule.residueHead[rid])
		while iAtom_in_rid != -1:
			atoms_in_rid.append(iAtom_in_rid)
			iAtom_in_rid = int(arg_baseMolecule.atomArray[iAtom_in_rid])

			for iFrame in range(numFrames):
				ridAxes, ridOrigin = arg_baseMolecule.get_basis_protein_residueBB(rid, iFrame)
				arg_hostDataContainer.rotationAxesArray[iFrame,atoms_in_rid,:] = nmp.vstack((ridAxes,ridOrigin))

		if arg_verbose >= 3:
			Utils.printflush('{:>5d}'.format(rid), end = ' ')
			if (rid+1) % 5 == 0:
				Utils.printflush('')
	# << OPERATION MALCOLM >>>
	Utils.printflush("")
	Utils.printflush("Done")


	# update local forces
	Utils.printflush("Updating Local forces->", end = ' ')
	arg_hostDataContainer.update_localForces_of_all_atoms(arg_type = "T")
	Utils.printflush('Done')

	# update local coordinates
	Utils.printflush("Updating Local coordinates->", end= ' ')
	arg_hostDataContainer.update_localCoords_of_all_atoms(arg_type="R")
	Utils.printflush('Done')


	#update torques in the arg_hostDataContainer if asked for (arg_tScale != 0)
	if arg_tScale != 0:
		Utils.printflush("Updating Local torques->", end = ' ')
		for iFrame in range(numFrames):
			for iAtom in arg_baseMolecule.atomIndexArray:
				coords_i = arg_hostDataContainer.localCoords[iFrame, iAtom]
				forces_i = arg_hostDataContainer.rotationAxesArray[iFrame, iAtom][0:3,]@arg_hostDataContainer._labForces[iFrame,iAtom]
				arg_hostDataContainer.localTorques[iFrame,iAtom,:] = CF.cross_product(coords_i,forces_i)

			# mass weighting the forces and torques
			for iBead in residueSystem.listOfBeads:

				# mass weighting the forces for each bead (iBead) in each direction (j) 
				#inertia weighting the torques for each bead (iBead) in each direction (j)

				# define local basis as the rotationalAxes of the first atom in the atomList of iBead 
				# doesnt matter because they all have the same R and T axes
				iLocalBasis = arg_hostDataContainer.rotationAxesArray[iFrame][iBead.atomList[0]]

				#get the moment of inertia tensor for ibead in thid local basis
				beadMOITensor = iBead.get_moment_of_inertia_tensor_local(arg_localBasis = iLocalBasis, arg_frame = iFrame)

				# get total torque and force in each direction and weight them by √beadMOITensor[jj]
				for j in range(3):
					iBead.totalWeightedForces[iFrame,j] = nmp.sum(nmp.asarray([arg_hostDataContainer.localForces[iFrame,aid,j] for aid in iBead.atomList]))
					iBead.totalWeightedTorques[iFrame,j] = nmp.sum(nmp.asarray([arg_hostDataContainer.localTorques[iFrame,aid,j] for aid in iBead.atomList]))

					if nmp.isclose(iBead.totalWeightedTorques[iFrame,j] , 0.0):
						# then the beadMOITensor[j,j] must be close to 0 as well (machine precision wise)
						# ensure that
						assert(nmp.isclose(beadMOITensor[j,j] , 0.0))
					else:
						iBead.totalWeightedTorques[iFrame,j] /= nmp.sqrt(beadMOITensor[j,j])

					# the above does nto apply for force
					iBead.totalWeightedForces[iFrame,j] /= nmp.sqrt(iBead.get_total_mass())

		Utils.printflush('Done')

	# now fill in the matrices
	Utils.printflush("Updating the submatrices ... ")
	residueSystem.update_subMatrix(arg_pairString="FF",arg_verbose=arg_verbose)
	if arg_tScale != 0:
		residueSystem.update_subMatrix(arg_pairString="TT",arg_verbose=arg_verbose)
	Utils.printflush('Done')

	#make quadrant from subMatrices
	Utils.printflush("Generating Quadrants->",end = ' ')
	ffQuadrant = residueSystem.generate_quadrant(arg_pairString="FF",arg_filterZeros=0)
	if arg_tScale != 0:
		ttQuadrant = residueSystem.generate_quadrant(arg_pairString="TT",arg_filterZeros=0)

	# scale forces/torques of these quadrants
	ffQuadrant = nmp.multiply(arg_fScale**2, ffQuadrant)
	if arg_tScale != 0:
		ttQuadrant = nmp.multiply(arg_tScale**2, ttQuadrant)
	
	# print matrices
	Writer.write_a_matrix(arg_matrix = ffQuadrant, arg_descriptor = "FF COV AT RESIDUE LEVEL", arg_outFile = arg_moutFile)
	if arg_tScale != 0:
		Writer.write_a_matrix(arg_matrix = ttQuadrant, arg_descriptor = "TT COV AT RESIDUE LEVEL", arg_outFile = arg_moutFile)

	# remove any row or column with zero axis
	# this could have been done while generating quadrants. Can be merged if wished for
	# ffQuadrant = residueSystem.filter_zero_rows_columns(ffQuadrant)
	# ttQuadrant = residueSystem.filter_zero_rows_columns(ttQuadrant)


	#diagnolaize
	Utils.printflush("Diagonalizing->", end = ' ')
	lambdasFF, eigVectorsFF  = Utils.diagonalize(ffQuadrant)
	if arg_tScale != 0:
		lambdasTT, eigVectorsTT  = Utils.diagonalize(ttQuadrant)
	Utils.printflush('Done')

	# since eigen values can be complex numbers but with imag parts very close to zero
	# use numpy's real_if_close with some tolerance to mask the imag parts
	# Utils.printflush('Checking the nature of eigen values and conditioning them ...', end = ' ')
	# tol = 1e+5
	# lambdasFF = nmp.real_if_close(lambdasFF/1e+5, tol= tol)
	# lambdasTT = nmp.real_if_close(lambdasTT/1e+5, tol= tol)
	# Utils.printflush('Done')

	# change to SI units
	Utils.printflush('Changing the units of eigen values to SI units->', end = ' ')
	lambdasFF = UAC.change_lambda_units(lambdasFF)
	if arg_tScale != 0:
		lambdasTT = UAC.change_lambda_units(lambdasTT)
	Utils.printflush('Done')

	# Create a spectrum to store these modes for 
	# proper output and analyses.
	modeSpectraFF = []
	for midx, mcombo in enumerate(zip(lambdasFF, eigVectorsFF)):
		fflmb, evec = mcombo
		# compute mode frequencies
		# nu = sqrt(lambda/kT)*(1/2pi)
		# Units: 1/s
		mfreq = compute_frequency_from_lambda(fflmb)
		newMode = ModeClasses.Mode(arg_modeIdx = midx + 1, \
			arg_modeEval = fflmb, \
			arg_modeEvec = evec, \
			arg_modeFreq = mfreq)
		newMode.set_mode_length(mfreq)
		modeSpectraFF.append(newMode)

	residueSystem.assign_attribute("modeSpectraFF", modeSpectraFF)


	if arg_tScale != 0:
		modeSpectraTT = []
		for midx, mcombo in enumerate(zip(lambdasTT, eigVectorsTT)):
			ttlmb, evec = mcombo
			# compute mode frequencies
			# nu = sqrt(lambda/kT)*(1/2pi)
			# Units: 1/s
			mfreq = compute_frequency_from_lambda(ttlmb)
			newMode = ModeClasses.Mode(arg_modeIdx = midx + 1, \
				arg_modeEval = ttlmb, \
				arg_modeEvec = evec, \
				arg_modeFreq = mfreq)
			newMode.set_mode_length(mfreq)
			modeSpectraTT.append(newMode)
		
		residueSystem.assign_attribute("modeSpectraTT", modeSpectraTT)

	# sorting the spectrum
	Utils.printflush('Sorting spectrum in ascending order of frequencies->', end = ' ')
	residueSystem.modeSpectraFF = ModeClasses.sort_modes(residueSystem.modeSpectraFF)
	if arg_tScale != 0:
		residueSystem.modeSpectraTT = ModeClasses.sort_modes(residueSystem.modeSpectraTT)
	Utils.printflush('Done')

	# Print modes
	outSpectraFF = "{}_FF_spectra.nmd".format(residueSystem.name)
	Writer.write_file(outSpectraFF)
	for ffmode in residueSystem.modeSpectraFF:		
		Utils.printOut(outSpectraFF, "# *** {} {:.3f}".format(ffmode.modeIdx, ffmode.modeFreq/UAC.C_LIGHT))
		Utils.printOut(outSpectraFF, ffmode.get_mode_info())

	if arg_tScale != 0:
		outSpectraTT = "{}_TT_spectra.nmd".format(residueSystem.name)
		Writer.write_file(outSpectraTT)
		for ttmode in residueSystem.modeSpectraTT:
			Utils.printOut(outSpectraTT, "# *** {} {:.3f}".format(ttmode.modeIdx, ttmode.modeFreq/UAC.C_LIGHT))
			Utils.printOut(outSpectraTT, ttmode.get_mode_info())

	# compute entropy
	# 1. remove the smallest 6 freqs from FF sprectrum 
	#     because they may be overlapping with whole molecule
	#     These 6 low frequency modes capture the translation and rotation at
	#     whole molecule level
	# 2. DO NOT remove any freq from TT spectrum because 
	#    they are uncoupled to any TT freq in any other hierarchy
	entropyFF = [calculate_entropy_per_dof(m.modeFreq) for m in residueSystem.modeSpectraFF[6:]]
	if arg_tScale != 0:
		entropyTT = [calculate_entropy_per_dof(m.modeFreq) for m in residueSystem.modeSpectraTT[0:]]

	# print final outputs
	Utils.printflush("Entropy values:")

	# print final outputs
	Utils.printflush('{:<40s} : {:.4f} J/mol/K'.format('FF Entropy (Residue level)',nmp.sum(entropyFF)))
	if arg_tScale != 0:
		Utils.printflush('{:<40s} : {:.4f} J/mol/K'.format('TT Entropy (Residue level)',nmp.sum(entropyTT)))
	
	Utils.printOut(arg_outFile,'{:<40s} : {:.4f} J/mol/K'.format('FF Entropy (Residue level)',nmp.sum(entropyFF)))
	if arg_tScale != 0:
		Utils.printOut(arg_outFile,'{:<40s} : {:.4f} J/mol/K'.format('TT Entropy (Residue level)',nmp.sum(entropyTT)))
	
	return 
#END


def compute_entropy_UA_level(arg_baseMolecule, 
                             arg_hostDataContainer, 
							 arg_outFile, 
							 arg_moutFile,
							 arg_fScale,
							 arg_tScale,
							 arg_verbose):
	""" 
	Computes the entropy calculations at the united atom (UA) level. 
	Each heavy atom with its covalently bonded H-atoms make a single bead. H-atoms
	are, however, treated explicitly.Determining translation and rotation axes is 
	part of the function. Translation axes for each bead is the C-Ca-N axes of the 
	residue the bead is part of. The rotation axes is a basis whose axes are directed
	along a sphereical-coordinate axes comprised of unit vectors along r,θ and Φ. 

	"""

	Utils.printflush('-'*60)
	Utils.printflush("{:^60}".format("Hierarchy level. --> United Atom <--"))
	Utils.printflush('-'*60)

	Utils.printOut(arg_outFile,'-'*60)
	Utils.printOut(arg_outFile,"{:^60}".format("Hierarchy level. --> United Atom <--"))
	Utils.printOut(arg_outFile,'-'*60)
	
	# preparing header for output file
	Utils.printOut(arg_outFile,'	  {:<10s}{:>5s}{:>12s}{:>12s}{:>12s}'.format('RESNAME', 'RESID', 'FF_ENTROPY', 'TT_ENTROPY', 'FREQUENCIES'))
	
	# initialize total entropy values
	totalUAEntropyFF = 0.
	totalUAEntropyTT = 0.
	
	# number of frames
	numFrames = len(arg_hostDataContainer.trajSnapshots)

	#reset
	arg_hostDataContainer.reset_rotationAxesArray()
	arg_hostDataContainer.reset_translationAxesArray()

	# for each residue:
	for rid in range(arg_baseMolecule.numResidues):
		resLabel = "{}{}".format(arg_baseMolecule.resnameArray[rid], arg_baseMolecule.residArray[rid])
		Utils.printflush('Working on resid : {}'.format(resLabel))

		# create a bead collection 
		ridBeadCollection = BC.BeadCollection("{}_bead".format(resLabel),arg_hostDataContainer)
		ridBeadCollection.listOfBeads = []

		# add UA beads to it
		atoms_in_rid = []
		iAtom_in_rid = int(arg_baseMolecule.residueHead[rid])
		while iAtom_in_rid != -1:

			atoms_in_rid.append(iAtom_in_rid)

			# if it is not a hydrogen
			if not arg_baseMolecule.isHydrogenArray[iAtom_in_rid]:
				atomList = [iAtom_in_rid]

				numBondedHydrogenAtoms = len(arg_baseMolecule.bondedHydrogenTable[iAtom_in_rid]) 
				if numBondedHydrogenAtoms != 0:
					# add all the bonded hydrogens to its list
					for iPriorityH,iH in arg_baseMolecule.bondedHydrogenTable[iAtom_in_rid].list_in_order():
						if iH != -1:
							atomList.append(iH)

				# create a bead
				newBead = BC.Bead(arg_atomList=atomList,
								  arg_hostDataContainer=arg_hostDataContainer,
								  arg_numFrames=numFrames,
								   	arg_beadName = arg_baseMolecule.atomNameArray[iAtom_in_rid],
									arg_beadResi = arg_baseMolecule.residArray[rid],
									arg_beadResn = arg_baseMolecule.resnameArray[rid],
									arg_beadChid = "X")
				ridBeadCollection.listOfBeads.append(newBead)
			else:
				pass

			iAtom_in_rid = int(arg_baseMolecule.atomArray[iAtom_in_rid])

		# by this point, the UA beads for that residue have been created
		Utils.printflush('Total number of UA beads in residue {} : {}'\
		              .format(resLabel, len(ridBeadCollection.listOfBeads)))

		# reset weighted vectors for each bead
		for iBead in ridBeadCollection.listOfBeads:
			iBead.reset_totalWeightedVectors( (numFrames,3) )

		# reseting all the F-T combo matrices to zero
		ridBeadCollection.reinitialize_matrices()

		# setup Translation and Rotation axes
		# Translation axes : each atom is in the c-ca-n axes of its host residue
		Utils.printflush("Assigning Translation Axes at the UA level->", end = ' ')
		for iFrame in range(numFrames):
			tAxes, tOrigin = arg_baseMolecule.get_basis_protein_residueBB(arg_frame=iFrame,arg_residueIndex=rid)
			arg_hostDataContainer.translationAxesArray[iFrame,atoms_in_rid,:] = nmp.vstack((tAxes, tOrigin))
		    
		Utils.printflush('Done')

		Utils.printflush("Assigning Rotational Axes at the UA level->", end = ' ')
		for iAtom_in_rid in atoms_in_rid:
			for iFrame in range(numFrames):
			    # Rotation axes : 
			    # the axes will have the geometry of a 
			    # local sphereical-polar coordinate system. 
			    if arg_baseMolecule.isHydrogenArray[iAtom_in_rid]:
			        # do nothing except do a check 
			        # on number of heavy atoms it is bonded to 
			        # should be exactly 1
			        assert(len(arg_baseMolecule.bondedHeavyAtomTable[iAtom_in_rid]) == 1)

			    else:
			        # it is a heavy atom
			        # from each of the hydrogen atoms bonded to it 
			        # get the average position lab coordinate
			        avgHydrogenPosition = get_avg_hpos(arg_atom= iAtom_in_rid, \
			        	arg_frame = iFrame, \
			        	arg_baseMolecule = arg_baseMolecule, \
			        	arg_hostDataContainer = arg_hostDataContainer)

			        # use the resultant vector to generate an 
			        # orthogonal local coordinate axes system
			        # with origin at the heavy atom position
			        heavyOrigin = arg_hostDataContainer._labCoords[iFrame, iAtom_in_rid]
			        iAtomBasis = nmp.vstack((GF.get_sphCoord_axes(arg_r=avgHydrogenPosition), heavyOrigin))

			        # heavy atom
			        arg_hostDataContainer.localCoords[iFrame, iAtom_in_rid] = arg_hostDataContainer._labCoords[iFrame, iAtom_in_rid] - iAtomBasis[-1]
			        arg_hostDataContainer.localCoords[iFrame, iAtom_in_rid] = iAtomBasis[0:3,] @ arg_hostDataContainer.localCoords[iFrame, iAtom_in_rid]
			        arg_hostDataContainer.rotationAxesArray[iFrame, iAtom_in_rid] = iAtomBasis

			        # its hydrogens
			        for iPriorityH, iH in arg_baseMolecule.bondedHydrogenTable[iAtom_in_rid].list_in_order():
			            arg_hostDataContainer.localCoords[iFrame, iH] = arg_hostDataContainer._labCoords[iFrame, iH] - iAtomBasis[-1]
			            arg_hostDataContainer.localCoords[iFrame, iH] = iAtomBasis[0:3,] @ arg_hostDataContainer.localCoords[iFrame, iH]
			            arg_hostDataContainer.rotationAxesArray[iFrame, iH] = iAtomBasis
		Utils.printflush('Done')

		# cast lab forces onto these axes simulateneously 
	    # unlike in the molecule and residue levels
		Utils.printflush('Casting forces at the UA level->',end=' ')
		for iAtom_in_rid in atoms_in_rid:
			for iFrame in range(numFrames):
				arg_hostDataContainer.localForces[iFrame][iAtom_in_rid] = arg_hostDataContainer.translationAxesArray[iFrame,iAtom_in_rid, 0:3] \
				                                                          @ arg_hostDataContainer._labForces[iFrame][iAtom_in_rid]
		Utils.printflush('Done')


		# update torques in the arg_hostDataContainer. T
		# his is redundant because local forces are not the ones that 
		# will be used to get the torques. Local coordinates however are.
		Utils.printflush('Casting torques at the UA level->', end = ' ')
		for iAtom_in_rid in atoms_in_rid:
			for iFrame in range(numFrames):
				coords_i = arg_hostDataContainer.localCoords[iFrame, iAtom_in_rid]
				forces_i = arg_hostDataContainer.rotationAxesArray[iFrame, iAtom_in_rid][0:3,]@arg_hostDataContainer._labForces[iFrame,iAtom_in_rid]
				arg_hostDataContainer.localTorques[iFrame,iAtom_in_rid,:] = CF.cross_product(coords_i,forces_i)
		Utils.printflush('Done')


		# mass weighting the forces and torque
		Utils.printflush('Computing total weighted forces and torques on each bead->', end = ' ')
		for iBead in ridBeadCollection.listOfBeads:
			for iFrame in range(numFrames):
			
				# mass weighting the forces for each bead (iBead) in each direction (j) 
				# inertia weighting the torques for each bead (iBead) in each direction (j)

				# define local basis as the rotationalAxes of the first atom in the atomList of iBead 
				# doesnt matter because they all have the same R and T axes
				iLocalBasis = arg_hostDataContainer.rotationAxesArray[iFrame][iBead.atomList[0]]

				#get the moment of inertia tensor for ibead in thid local basis
				beadMOITensor = iBead.get_moment_of_inertia_tensor_local(arg_localBasis = iLocalBasis, arg_frame = iFrame)

				# get total torque and force in each direction and weight them by √beadMOITensor[jj]
				for j in range(3):
					iBead.totalWeightedForces[iFrame,j] = nmp.sum(nmp.asarray([arg_hostDataContainer.localForces[iFrame,aid,j] for aid in iBead.atomList]))
					iBead.totalWeightedTorques[iFrame,j] = nmp.sum(nmp.asarray([arg_hostDataContainer.localTorques[iFrame,aid,j] for aid in iBead.atomList]))
					
					try:
						assert(iBead.get_total_mass() != 0)
					except:
						raise AssertionError("Bead with zero mass found. Clearly an error!")
					
					# mass weight the total force component
					iBead.totalWeightedForces[iFrame,j] /= nmp.sqrt(iBead.get_total_mass())

					try:
						if nmp.isclose(iBead.totalWeightedTorques[iFrame,j] , 0.0):
							# then the beadMOITensor[j,j] must be 0 as well
							# ensure that
							assert(nmp.isclose(beadMOITensor[j,j] , 0.0))
						else:
							# inertia weight the total torque component
							iBead.totalWeightedTorques[iFrame,j] /= nmp.sqrt(beadMOITensor[j,j])
					except:
						raise AssertionError("Moment of Intertia is non-zero for a bead lying on axis {}".format(j))
						
		Utils.printflush('Done')

		# now fill in the matrices
		Utils.printflush("Updating the submatrices ... ")
		ridBeadCollection.update_subMatrix(arg_pairString="FF",arg_verbose=arg_verbose)
		ridBeadCollection.update_subMatrix(arg_pairString="TT",arg_verbose=arg_verbose)
		Utils.printflush('Done')

		#make quadrant from subMatrices
		Utils.printflush("Generating Quadrants->",end = ' ')
		ffQuadrant = ridBeadCollection.generate_quadrant(arg_pairString="FF",arg_filterZeros=0)
		ttQuadrant = ridBeadCollection.generate_quadrant(arg_pairString="TT",arg_filterZeros=0)
	
		# scale forces/torques of these quadrants
		ffQuadrant = nmp.multiply(arg_fScale**2, ffQuadrant)
		ttQuadrant = nmp.multiply(arg_tScale**2, ttQuadrant)

		# remove any row or column with zero axis
		# this could have been done while generating quadrants. Can be merged if wished for
		ffQuadrant = ridBeadCollection.filter_zero_rows_columns(ffQuadrant)
		ttQuadrant = ridBeadCollection.filter_zero_rows_columns(ttQuadrant)


		# print matrices
		Writer.write_a_matrix(arg_matrix = ffQuadrant\
		                      , arg_descriptor = "FF COV AT UNITED ATOM LEVEL FOR RES {}".format(resLabel)\
							  , arg_outFile = arg_moutFile)
		Writer.write_a_matrix(arg_matrix = ttQuadrant\
		                      , arg_descriptor = "TT COV AT UNITED ATOM LEVEL FOR RES {}".format(resLabel)\
							  , arg_outFile = arg_moutFile)
		
		#diagnolaize
		Utils.printflush("Diagonalizing->", end = ' ')
		lambdasFF, eigVectorsFF  = Utils.diagonalize(ffQuadrant)
		lambdasTT, eigVectorsTT  = Utils.diagonalize(ttQuadrant)
		Utils.printflush('Done')

		# since eigen values can be complex numbers 
		# but with imag parts very close to zero
		# use numpy's real_if_close with some tolerance to mask the imag parts
		# Utils.printflush('Checking the nature of eigen values and conditioning them ...', end = ' ')
		# tol = 1e+5
		# lambdasFF = nmp.real_if_close(lambdasFF/1e+5, tol= tol)
		# lambdasTT = nmp.real_if_close(lambdasTT/1e+5, tol= tol)
		# Utils.printflush('Done')

		# filter real zero values
		lambdasFF = nmp.asarray([lm for lm in lambdasFF if not nmp.isclose(lm, 0.0)])
		lambdasTT = nmp.asarray([lm for lm in lambdasTT if not nmp.isclose(lm, 0.0)])


		# change to SI units
		Utils.printflush('Changing the units of eigen values to SI units->', end = ' ')
		lambdasFF = UAC.change_lambda_units(lambdasFF)
		lambdasTT = UAC.change_lambda_units(lambdasTT)
		Utils.printflush('Done')

		# Create a spectrum to store these modes for 
		# proper output and analyses.
		modeSpectraFF = []
		for midx, mcombo in enumerate(zip(lambdasFF, eigVectorsFF)):
			fflmb, evec = mcombo
			# compute mode frequencies
			# nu = sqrt(lambda/kT)*(1/2pi)
			# Units: 1/s
			mfreq = compute_frequency_from_lambda(fflmb)
			newMode = ModeClasses.Mode(arg_modeIdx = midx + 1, \
				arg_modeEval = fflmb, \
				arg_modeEvec = evec, \
				arg_modeFreq = mfreq)
			newMode.set_mode_length(mfreq)
			modeSpectraFF.append(newMode)

		ridBeadCollection.assign_attribute("modeSpectraFF", modeSpectraFF)


		modeSpectraTT = []
		for midx, mcombo in enumerate(zip(lambdasTT, eigVectorsTT)):
			ttlmb, evec = mcombo
			# compute mode frequencies
			# nu = sqrt(lambda/kT)*(1/2pi)
			# Units: 1/s
			mfreq = compute_frequency_from_lambda(ttlmb)
			newMode = ModeClasses.Mode(arg_modeIdx = midx + 1, \
				arg_modeEval = ttlmb, \
				arg_modeEvec = evec, \
				arg_modeFreq = mfreq)
			newMode.set_mode_length(mfreq)
			modeSpectraTT.append(newMode)
		
		ridBeadCollection.assign_attribute("modeSpectraTT", modeSpectraTT)

		# sorting the spectrum
		Utils.printflush('Sorting spectrum in ascending order of frequencies->', end = ' ')
		ridBeadCollection.modeSpectraFF = ModeClasses.sort_modes(ridBeadCollection.modeSpectraFF)
		ridBeadCollection.modeSpectraTT = ModeClasses.sort_modes(ridBeadCollection.modeSpectraTT)
		Utils.printflush('Done')

		# Print modes
		outSpectraFF = "{}_FF_spectra.nmd".format(ridBeadCollection.name)
		Writer.write_file(outSpectraFF)
		for ffmode in ridBeadCollection.modeSpectraFF:		
			Utils.printOut(outSpectraFF, "# *** {} {:.3f}".format(ffmode.modeIdx, ffmode.modeFreq/UAC.C_LIGHT))
			Utils.printOut(outSpectraFF, ffmode.get_mode_info())

		outSpectraTT = "{}_TT_spectra.nmd".format(ridBeadCollection.name)
		Writer.write_file(outSpectraTT)
		for ttmode in ridBeadCollection.modeSpectraTT:
			Utils.printOut(outSpectraTT, "# *** {} {:.3f}".format(ttmode.modeIdx, ttmode.modeFreq/UAC.C_LIGHT))
			Utils.printOut(outSpectraTT, ttmode.get_mode_info())

		# compute entropy
		# 1. remove the smallest 6 freqs from FF sprectrum 
		#     because they may be overlapping with residue level motions
		# 2. DO NOT remove any freq from TT spectrum because 
		#    they are uncoupled to any TT freq in any other hierarchy
		entropyFF = [calculate_entropy_per_dof(m.modeFreq) for m in ridBeadCollection.modeSpectraFF[6:]]
		entropyTT = [calculate_entropy_per_dof(m.modeFreq) for m in ridBeadCollection.modeSpectraTT[0:]]

		ridTotalEntropyFF = nmp.sum(entropyFF)
		ridTotalEntropyTT = nmp.sum(entropyTT)

		# print final outputs
		Utils.printflush("Entropy values:")

		Utils.printflush('{:<40s} : {:.4f} J/mol/K'.format('FF Entropy (UA for {})'.format(resLabel), ridTotalEntropyFF))
		Utils.printflush('{:<40s} : {:.4f} J/mol/K'.format('TT Entropy (UA for {})'.format(resLabel), ridTotalEntropyTT))
		Utils.printOut(arg_outFile,'UATOM {:<10}{:>5}{:>12.3f}{:>12.3f}'\
		                        .format(arg_baseMolecule.resnameArray[rid]\
								, arg_baseMolecule.residArray[rid]\
								, ridTotalEntropyFF\
								, ridTotalEntropyTT))

		totalUAEntropyFF += ridTotalEntropyFF
		totalUAEntropyTT += ridTotalEntropyTT

	# Final information	
	Utils.printflush('_'*60)
	Utils.printflush('{:<25} : {:>15.3f} J/mol/K'.format('Total Entropy FF (UA level)', totalUAEntropyFF))
	Utils.printflush('{:<25} : {:>15.3f} J/mol/K'.format('Total Entropy TT (UA level)', totalUAEntropyTT))
	Utils.printflush('-'*60)

	Utils.printOut(arg_outFile,'_'*60)
	Utils.printOut(arg_outFile,'{:<25} : {:>15.3f} J/mol/K'.format('Total Entropy FF (UA level)', totalUAEntropyFF))
	Utils.printOut(arg_outFile,'{:<25} : {:>15.3f} J/mol/K'.format('Total Entropy TT (UA level)', totalUAEntropyTT))
	Utils.printOut(arg_outFile,'-'*60)
	
	return 
#END

def compute_topographical_entropy0_SC(arg_baseMolecule, arg_hostDataContainer, arg_outFile, arg_verbose):
	""" A code that computes the topographical entropy using the formula S = -Sum(pLog(p)). 
	Every SC dihedral from every residue will be scanned. 
	Each dihedral will be depicted using a vector of order 3 of the form |g+, g-, t> (arbitrarily chosen) and 
	so can have a maximum of three different configurations it can be in. Its probability of being in each of 
	these states will be computed and entropy will be coputed form that."""


	Utils.printflush('-'*60)
	Utils.printflush("{:^60}".format("Topographical entropy of residue side chains \n computed using all the dihedrals with pLogp formalism"))
	Utils.printflush('-'*60)

	Utils.printOut(arg_outFile,'-'*60)
	Utils.printOut(arg_outFile,"{:^60}".format("Topographical entropy of residue side chains \n computed using all the dihedrals with pLogp formalism"))
	Utils.printOut(arg_outFile,'-'*60)

	# number of frames
	numFrames = len(arg_hostDataContainer.trajSnapshots)

	# log of number of frames (a constant)
	logNumFrames = nmp.log(numFrames)

	# conformation vector order |g+, g-, t>
	vecOrder = 3

	# total SC entropy
	totalTopogEntropySC = 0.

	# browse through each residue in the system and get their dihedrals
	for rid in range(arg_baseMolecule.numResidues):
		Utils.printflush('-'*10,end='')
		Utils.printflush('Working on resid : {} ({})'.format(rid, arg_baseMolecule.resnameArray[rid]), end='')
		Utils.printflush('-'*10)
	

		# total SC entropy at the topographical level of thi residue
		ridTopogEntropy = 0.

		diheds_in_rid = set()
		iAtom_in_rid = int(arg_baseMolecule.residueHead[rid])
		while iAtom_in_rid != -1:

			for iDih in arg_baseMolecule.dihedralTable[iAtom_in_rid]:
				# see if it is exclusive to this resid because they could also be peptide bond diheds
				if iDih.is_from_same_residue() == rid and (iDih.is_heavy_dihedral())  and (not iDih.is_BB_dihedral()):
					diheds_in_rid.add(iDih)

			iAtom_in_rid = int(arg_baseMolecule.atomArray[iAtom_in_rid])

		Utils.printflush('Found {} exclusive dihedrals in residue {}'.format(len(diheds_in_rid), arg_baseMolecule.resnameArray[rid]))

		# define a list of ConformationEntities for this residue
		conformationEntityList = []

		for iDih in diheds_in_rid:
			dihAtoms = {"atom1": iDih.atom1, 
		            "atom2":     iDih.atom2, 
		            "atom3":     iDih.atom3, 
		            "atom4":     iDih.atom4,
		            "isBB" :     iDih.is_BB_dihedral(),
		            "isHeavy" :  iDih.is_heavy_dihedral(),
		            "isSameRes" : iDih.is_from_same_residue()}
			
			# make an entity from this dihedral
			newEntity = CONF.ConformationEntity(arg_order = vecOrder, arg_numFrames = numFrames, **dihAtoms)
		
			# generate a time series of the conformations it acquires.
			# at each frame
			for iFrame in range(numFrames):

				# fetch the dihedral value at that frame
				phi = iDih.get_dihedral_angle_lab(arg_dataContainer = arg_hostDataContainer, arg_frame = iFrame)

				# define its status
				isGaucheP = ( 0 <= phi < 120)
				isGaucheN = ( 0 > phi >= -120 )
				isTrans   = ( phi >= 120 or phi < -120)

				# place it in the time series block appropriately
				newEntity.timeSeries[:,iFrame] = nmp.asarray([isGaucheP, isGaucheN, isTrans]).astype(int)

			# add this dihedral into the list of conformation entities
			conformationEntityList.append(newEntity)

		# go over each entity and find its entropy. Add its entropy to the total entropy.
		for iEntity in conformationEntityList:
			sEntity = 0.

			for iRow in range(vecOrder):
				# get the total number of occurences of '1' in that row ( count )
				iCount = nmp.sum(iEntity.timeSeries[iRow,:])

				if iCount != 0:
					# means that state was atained at least once
					# p Log(p) for this state
					iPlogP = iCount * (nmp.log(iCount) - logNumFrames)

					sEntity += iPlogP;


			sEntity /= numFrames
			sEntity *= -UAC.GAS_CONST #(R)

			# add entropy of this entity to the residue's SC topographical entropy
			ridTopogEntropy += sEntity

			Utils.printflush('Dihedral {:<5d}{:<5d}{:<5d}{:<5d} : {:.4f}'.format(iEntity.atom1, iEntity.atom2, iEntity.atom3, iEntity.atom4, sEntity))
			Utils.printOut(arg_outFile, 'Dihedral {:<5d}{:<5d}{:<5d}{:<5d} : {:.4f}'.format(iEntity.atom1, iEntity.atom2, iEntity.atom3, iEntity.atom4, sEntity))


		# Final residue SC information	
		Utils.printflush('_'*60)
		Utils.printflush('{:<40s} : {:.4f}'.format('Side Chain Topographical Entropy ({} {})'.format(arg_baseMolecule.resnameArray[rid], arg_baseMolecule.residArray[rid]), ridTopogEntropy))
		Utils.printflush('-'*60)

		Utils.printOut(arg_outFile, '_'*60)
		Utils.printOut(arg_outFile, '{:<40s} : {:.4f}'.format('Side Chain Topographical Entropy ({} {})'.format(arg_baseMolecule.resnameArray[rid], arg_baseMolecule.residArray[rid]), ridTopogEntropy))
		Utils.printOut(arg_outFile, '-'*60)

		# add this residue's SC entropy to the total SC entropy
		totalTopogEntropySC += ridTopogEntropy 

	# total SC topographical entropy
	Utils.printflush('_'*60)
	Utils.printflush('{:<40} : {:>15.3f}'.format('Total SC Topog. Entropy ', totalTopogEntropySC))
	Utils.printflush('-'*60)

	Utils.printOut(arg_outFile, '_'*60)
	Utils.printOut(arg_outFile, '{:<40} : {:>15.3f}'.format('Total SC Topog. Entropy ', totalTopogEntropySC))
	Utils.printOut(arg_outFile, '-'*60)

	return
#END

def compute_topographical_entropy0_BB(arg_baseMolecule, arg_hostDataContainer, arg_outFile, arg_verbose):
	""" A code that computes the topographical entropy using the formula S = -Sum(pLog(p)). 
	Every BB dihedral from the protein will be scanned. 
	Each dihedral will be depicted using a vector of order 3 of the form |g+, g-, t> (arbitrarily chosen) and 
	so can have a maximum of three different configurations it can be in. Its probability of being in each of 
	these states will be computed and entropy will be coputed form that."""


	Utils.printflush('-'*60)
	Utils.printflush("{:^60}".format("Topographical entropy of BB dihedrals \n computed using the pLogp formalism"))
	Utils.printflush('-'*60)

	Utils.printOut(arg_outFile,'-'*60)
	Utils.printOut(arg_outFile,"{:^60}".format("Topographical entropy of BB dihedrals \n computed using the pLogp formalism"))
	Utils.printOut(arg_outFile,'-'*60)

	# number of frames
	numFrames = len(arg_hostDataContainer.trajSnapshots)

	# log of number of frames (a constant)
	logNumFrames = nmp.log(numFrames)

	# conformation vector order |g+, g-, t>
	vecOrder = 3

	# total BB entropy
	totalTopogEntropyBB = 0.


	# fetch all the heavy BB dihedrals
	bbDiheds = list(filter(lambda dih: dih.is_BB_dihedral() and dih.is_heavy_dihedral(), arg_baseMolecule.dihedralArray))
	Utils.printflush('Found a total of {} BB dihedrals.'.format(len(bbDiheds)))


	# define a list of ConformationEntities to store all the BB dihedrals
	conformationEntityList = []

	for iBBDih in bbDiheds:
		dihAtoms = {"atom1": iBBDih.atom1, 
	            "atom2":     iBBDih.atom2, 
	            "atom3":     iBBDih.atom3, 
	            "atom4":     iBBDih.atom4,
	            "isBB" :     iBBDih.is_BB_dihedral(),
	            "isHeavy" :  iBBDih.is_heavy_dihedral(),
	            "isSameRes" : iBBDih.is_from_same_residue()}
		
		# make an entity from this dihedral
		newEntity = CONF.ConformationEntity(arg_order = vecOrder, arg_numFrames = numFrames, **dihAtoms)
		
		# generate a time series of the conformations it acquires.
		# at each frame
		for iFrame in range(numFrames):

			# fetch the dihedral value at that frame
			phi = iBBDih.get_dihedral_angle_lab(arg_dataContainer = arg_hostDataContainer, arg_frame = iFrame)

			# define its status
			isGaucheP = ( 0 <= phi < 120)
			isGaucheN = ( 0 > phi >= -120 )
			isTrans   = ( phi >= 120 or phi < -120)

			# create an instance of ConformationVector
			v = nmp.asarray([isGaucheP, isGaucheN, isTrans]).astype(int)

			# place it in the time series block appropriately
			newEntity.timeSeries[:,iFrame] = v

		# add this dihedral into the list of conformation entities
		conformationEntityList.append(newEntity)

	# go over each entity and find its entropy. Add its entropy to the total BB topographical entropy.
	for iEntity in conformationEntityList:
		sEntity = 0.

		for iRow in range(vecOrder):
			# get the total number of occurences of '1' in that row ( count )
			iCount = nmp.sum(iEntity.timeSeries[iRow,:])

			if iCount != 0:
				# means that state was atained at least once
				# p Log(p) for this state
				iPlogP = iCount * (nmp.log(iCount) - logNumFrames)

				sEntity += iPlogP;


		sEntity /= numFrames
		sEntity *= -UAC.GAS_CONST #(R)

		Utils.printflush('Dihedral {:<5d}{:<5d}{:<5d}{:<5d} : {:.4f} ({:>5d})'.format(iEntity.atom1, iEntity.atom2, iEntity.atom3, iEntity.atom4, sEntity, iEntity.isSameRes))
		Utils.printOut(arg_outFile, 'Dihedral {:<5d}{:<5d}{:<5d}{:<5d} : {:.4f} ({:>5d})'.format(iEntity.atom1, iEntity.atom2, iEntity.atom3, iEntity.atom4, sEntity, iEntity.isSameRes))

		# add entropy of this entity to the residue's SC topographical entropy
		totalTopogEntropyBB += sEntity


	# total BB topographical entropy
	Utils.printflush('_'*60)
	Utils.printflush('{:<40} : {:>15.3f}'.format('Total BB Topog. Entropy ', totalTopogEntropyBB))
	Utils.printflush('-'*60)

	Utils.printOut(arg_outFile, '_'*60)
	Utils.printOut(arg_outFile, '{:<40} : {:>15.3f}'.format('Total BB Topog. Entropy ', totalTopogEntropyBB))
	Utils.printOut(arg_outFile, '-'*60)

	return
#END

def compute_topographical_entropy1_SC(arg_baseMolecule, arg_hostDataContainer, arg_outFile, arg_verbose):
	""" A function that computes the entropy over the states acquired by the a residue in terms of the states acquired by 
	its dihedrals by also accounting for their correlated motions. A residue is depicted as a vector of length N_d where N_d 
	is the number of dihedrals. Each dihedral is represented using an integer which is a decimal equivalent of its state of some order Q
	which is represented by a binary vector of that size. At each time frame, a vector of integers of size N_d is stored and it stores that
	time frame uniquely. All the different states acquired are then used to compute the entropy using p-logP. """

	Utils.printflush('-'*60)
	Utils.printflush("{:^60}".format("Topographical entropy of residue side chains \ncomputed using all the dihedrals with correlation/pLogp formalism"))
	Utils.printflush('-'*60)

	Utils.printOut(arg_outFile,'-'*60)
	Utils.printOut(arg_outFile,"{:^60}".format("Topographical entropy of residue side chains \ncomputed using all the dihedrals with correlation/pLogp formalism"))
	Utils.printOut(arg_outFile,'-'*60)

	# number of frames
	numFrames = len(arg_hostDataContainer.trajSnapshots)

	# log of number of frames (a constant)
	logNumFrames = nmp.log(numFrames)

	# conformation vector order |g+, g-, t>
	vecOrder = 3   # (= Q)

	# total SC entropy
	totalTopogEntropySC = 0.

	# define a list of ConformationEntities where each element corresponds to a residue
	conformationEntityList = []	

	# browse through each residue in the system and get their dihedrals
	for rid in range(arg_baseMolecule.numResidues):
		Utils.printflush('-'*10,end='')
		Utils.printflush('Working on resid : {} ({})'.format(rid, arg_baseMolecule.resnameArray[rid]), end='')
		Utils.printflush('-'*10)


		diheds_in_rid = set()
		iAtom_in_rid = int(arg_baseMolecule.residueHead[rid])
		while iAtom_in_rid != -1:

			for iDih in arg_baseMolecule.dihedralTable[iAtom_in_rid]:
				# see if it is exclusive to this resid because they could also be peptide bond diheds
				if iDih.is_from_same_residue() == rid and iDih.is_heavy_dihedral():
					diheds_in_rid.add(iDih)

			iAtom_in_rid = int(arg_baseMolecule.atomArray[iAtom_in_rid])

		Utils.printflush('Found {} exclusive dihedrals in residue {}'.format(len(diheds_in_rid), arg_baseMolecule.resnameArray[rid]))

		# create an object of Class ConformationEntity corresponding to this residue
		newEntity = CONF.ConformationEntity(arg_order = len(diheds_in_rid), arg_numFrames = numFrames)

		# also initialize a string array that will store the state in each frame as a distinct string
		# made from coalesced character cast of numeric arrays
		ridDecimalReprArray = []

		# at each frame
		for iFrame in range(numFrames):

			# fetch the dihedral value of each of the dihedrals for this residue at that frame
			for i, iDih in enumerate(diheds_in_rid):
				phi = iDih.get_dihedral_angle_lab(arg_dataContainer = arg_hostDataContainer, arg_frame = iFrame)

				# define its status
				isGaucheP = ( 0 <= phi < 120)
				isGaucheN = ( 0 > phi >= -120 )
				isTrans   = ( phi >= 120 or phi < -120)

				v = bytearray([isGaucheP, isGaucheN, isTrans])
				newEntity.timeSeries[i,iFrame] = Utils.binary_to_dec_repr(v)

			# populate the ridDecimalReprArray appropriately
			ridDecimalReprArray.append(Utils.coalesce_numeric_array(newEntity.timeSeries[:,iFrame]))

		# for each of the unique state get their count and compute the topographical entropy for this residue
		setOfstates = set(ridDecimalReprArray)
		Utils.printflush('Found {} dihedrals which collectively acquire {} unique conformers'.format(len(diheds_in_rid), len(setOfstates)))

		# print(ridDecimalReprArray)

		# total SC entropy at the topographical level of this residue
		ridTopogEntropy = 0.

		for iState in setOfstates:
			iCount = ridDecimalReprArray.count(iState) 

			# p Log(p) for this state
			iPlogP = iCount * (nmp.log(iCount) - logNumFrames)
			ridTopogEntropy += iPlogP;

		ridTopogEntropy /= numFrames;
		ridTopogEntropy *= -UAC.GAS_CONST  #(R)

		# Final residue SC information	
		Utils.printflush('_'*60)
		Utils.printflush('{:<40s} : {:.4f}'.format('Side Chain Topographical Entropy from corr. pLogP method ({} {})'.format(arg_baseMolecule.resnameArray[rid], arg_baseMolecule.residArray[rid]), ridTopogEntropy))
		Utils.printflush('-'*60)

		Utils.printOut(arg_outFile, '_'*60)
		Utils.printOut(arg_outFile, '{:<40s} : {:.4f}'.format('Side Chain Topographical Entropy from corr. pLogP method ({} {})'.format(arg_baseMolecule.resnameArray[rid], arg_baseMolecule.residArray[rid]), ridTopogEntropy))
		Utils.printOut(arg_outFile, '-'*60)

		# add this residue's SC entropy to the total SC entropy
		totalTopogEntropySC += ridTopogEntropy
			
	# total SC topographical entropy
	Utils.printflush('_'*60)
	Utils.printflush('{:<40} : {:>15.3f}'.format('Total SC Topog. Entropy (corr. pLogP) ', totalTopogEntropySC))
	Utils.printflush('-'*60)

	Utils.printOut(arg_outFile, '_'*60)
	Utils.printOut(arg_outFile, '{:<40} : {:>15.3f}'.format('Total SC Topog. Entropy (corr. pLogP)', totalTopogEntropySC))
	Utils.printOut(arg_outFile, '-'*60)

	return
#END

def compute_topographical_entropy1_BB(arg_baseMolecule, arg_hostDataContainer, arg_outFile, arg_verbose):
	""" A function that computes the entropy over the states acquired collectively by the heavy BB dihedrals in a protein
	 by also accounting for their correlated motions. A proteins' colleciton of BB diheds is depicted as a vector of length N_d where
	N_d is the number of BB dihedrals. Each dihedral's state is represented using 0/1 telling which state it was in. Then at each time frame, 
	the state of a dihedral is computed and represented using a decimal equivalent of its buytearray form. For the entire protein, each time 
	frame has a tuple of integers corresponding to it which describes it uniquely. All the different states acquired are then used to compute the 
	entropy using p-logP. """

	

	Utils.printflush('-'*60)
	Utils.printflush("{:^60}".format("Topographical entropy of BB dihedrals \ncomputed using the correlated-pLogp formalism"))
	Utils.printflush('-'*60)

	Utils.printOut(arg_outFile,'-'*60)
	Utils.printOut(arg_outFile,"{:^60}".format("Topographical entropy of BB dihedrals \ncomputed using the correlated-pLogp formalism"))
	Utils.printOut(arg_outFile,'-'*60)

	# number of frames
	numFrames = len(arg_hostDataContainer.trajSnapshots)

	# log of number of frames (a constant)
	logNumFrames = nmp.log(numFrames)

	# conformation vector order |g+, g-, t>
	vecOrder = 3

	# total BB entropy
	totalTopogEntropyBB = 0.

	# fetch all the heavy BB dihedrals
	bbDiheds = list(filter(lambda dih: dih.is_BB_dihedral() and dih.is_heavy_dihedral(), arg_baseMolecule.dihedralArray))

	# create an instance of Class ConformationEntity that will contain all of these BB diheds
	newEntity = CONF.ConformationEntity(arg_order = len(bbDiheds), arg_numFrames = numFrames)

	# also initialize a string array that will store the state in each frame as a distinct string
	# made from coalesced character cast of numeric arrays
	bbDecimalReprArray = []   

	# at each frame
	for iFrame in range(numFrames):

		# fetch the dihedral value of each of the BB dihedrals in the protein at that frame
		for i, iDih in enumerate(bbDiheds):
			phi = iDih.get_dihedral_angle_lab(arg_dataContainer = arg_hostDataContainer, arg_frame = iFrame)

			# define its status
			isGaucheP = ( 0 <= phi < 120)
			isGaucheN = ( 0 > phi >= -120 )
			isTrans   = ( phi >= 120 or phi < -120)

			v = bytearray([isGaucheP, isGaucheN, isTrans])
			newEntity.timeSeries[i,iFrame] = Utils.binary_to_dec_repr(v)


		# populate the bbDecimalReprArray appropriately
		bbDecimalReprArray.append(Utils.coalesce_numeric_array(newEntity.timeSeries[:,iFrame]))

	# for each of the unique state get their count and compute the topographical entropy for this residue
	setOfstates = set(bbDecimalReprArray)

	Utils.printflush('Found {} dihedrals which collectively acquire {} unique conformers'.format(len(bbDiheds), len(setOfstates)))

	# total BB entropy at the topographical level 
	totalTopogEntropyBB = 0.

	for iState in setOfstates:
		iCount = bbDecimalReprArray.count(iState) 

		# p Log(p) for this state
		iPlogP = iCount * (nmp.log(iCount) - logNumFrames)
		totalTopogEntropyBB += iPlogP;

	totalTopogEntropyBB /= numFrames;
	totalTopogEntropyBB *= -UAC.GAS_CONST  #(R)

	# total BB topographical entropy
	Utils.printflush('_'*60)
	Utils.printflush('{:<40} : {:>15.3f}'.format('Total BB Topog. Entropy (corr. pLogP) ', totalTopogEntropyBB))
	Utils.printflush('-'*60)

	Utils.printOut(arg_outFile, '_'*60)
	Utils.printOut(arg_outFile, '{:<40} : {:>15.3f}'.format('Total BB Topog. Entropy (corr. pLogP) ', totalTopogEntropyBB))
	Utils.printOut(arg_outFile, '-'*60)

	return
#END

def compute_topographical_entropy_method4(arg_baseMolecule, arg_hostDataContainer, arg_outFile, arg_verbose):
	"""
	Function that computes the topographical entropy using Method 4,
	a.k.a the dihedral-state-contingency method.
	"""

	Utils.printflush('-'*60)
	Utils.printflush("{:^60}".format("Topographical entropy using dihedral-state-contingency method"))
	Utils.printflush('-'*60)

	Utils.printOut(arg_outFile,'-'*60)
	Utils.printOut(arg_outFile,"{:^60}".format("Topographical entropy using dihedral-state-contingency method"))
	Utils.printOut(arg_outFile,'-'*60)

	# number of frames
	numFrames = len(arg_hostDataContainer.trajSnapshots)

	# conformation vector order |g+, g-, t>
	vecOrder = 3   # (= Q)

	# initialize total entropy from all residues
	totalTopogEntropy4 = 0

	# all the dihedrals will be computed using coordinates projected onto 
	# molecular principal axes frames. (It should howver not matter what 
	# axes system we chose because dihedrals are measured using vector differences
	# which should not depend on the choice of coordinate systems).
	CF.cast_translationAxesArray_at_molecule_level(arg_dataContainer=arg_hostDataContainer)

	# update local coordinates
	if arg_verbose >= 2:
		Utils.printflush("Updating Local coordinates based on new Principal Axes ... ",end= ' ')
	
	arg_hostDataContainer.update_localCoords_of_all_atoms(arg_type="T")
	
	if arg_verbose >= 2:
		Utils.printflush('Done')

	#
	#
	#      Residue wise calculation of topographical entropy
	#
	#
	for rid in range(arg_baseMolecule.numResidues):
		Utils.printflush('-'*10,end='')
		Utils.printflush('Working on resid : {} ({})'.format(rid, arg_baseMolecule.resnameArray[rid]), end='')
		Utils.printflush('-'*10)

		dihedsInRid = set()
		iAtomInRid = int(arg_baseMolecule.residueHead[rid])
		while iAtomInRid != -1:

			for iDih in arg_baseMolecule.dihedralTable[iAtomInRid]:
				# see if it is exclusive to this resid because they could also be peptide bond diheds
				if iDih.is_from_same_residue() == rid and iDih.is_heavy_dihedral():
					dihedsInRid.add(iDih)

			iAtomInRid = int(arg_baseMolecule.atomArray[iAtomInRid])

		numDiheds = len(dihedsInRid)
		if arg_verbose >= 2:
			Utils.printflush('Found {} exclusive dihedrals in residue {}\
			              '.format(numDiheds, arg_baseMolecule.resnameArray[rid]))
	
		# treat each dihedral as a conformation entity
		# initialize a list of ConformationEntities for this molecule
		conformationEntityList = []


		# for each heavy dihedral
		for iDih in dihedsInRid:
				
			# make an entity from this dihedral
			newEntity = CONF.ConformationEntity(arg_order = vecOrder, arg_numFrames = numFrames)

			# generate a time series of the conformations it acquires.
			# at each frame
			for iFrame in range(numFrames):

				# fetch the dihedral value at that frame
				phi = iDih.get_dihedral_angle_local(arg_dataContainer = arg_hostDataContainer, arg_frame = iFrame)

				# define its status
				isGaucheP = ( 0 <= phi < 120)
				isGaucheN = ( 0 > phi >= -120 )
				isTrans   = ( phi >= 120 or phi < -120)

				# place it in the time series block appropriately
				newEntity.timeSeries[:,iFrame] = nmp.asarray([isGaucheP, isGaucheN, isTrans], dtype = nmp.int8)

			# add this dihedral into the list of conformation entities
			conformationEntityList.append(newEntity)


		#-------------------------------------------------------------------------------------
		#
		#          initialize and populate the symmetric occupancy matrix (for the residue)
		#
		#-------------------------------------------------------------------------------------
		# initialize
		occuMatrix = -1000 * nmp.ones((numDiheds*vecOrder, numDiheds*vecOrder))
		Utils.printOut(arg_outFile, "Occupancy matrix for Residue {}".format(arg_baseMolecule.resnameArray[rid]))

		# populate
		for i in range(0,numDiheds):
			iDih = conformationEntityList[i]
			if arg_verbose >= 2: 
				Utils.printflush('Dihedral {} : |'.format(i), end = ' ' )	

			for j in range(i, numDiheds):
				jDih = conformationEntityList[j]
				if arg_verbose >= 2: 
					Utils.printflush('.',end='')

				for iState in range(vecOrder):
					idx = (vecOrder * i) + iState
					iDihTimeSeries = iDih.timeSeries[iState,:]

					for jState in range(vecOrder):
						jdx = (vecOrder * j) + jState
						jDihTimeSeries = jDih.timeSeries[jState,:]
				
						# get the determinant of the contingency matrix computed from 
						# the dihedral states for this pair of dihedrals
						ijElement = CF.phi_coeff(arg_v1 = iDihTimeSeries\
						                                     , arg_v2 = jDihTimeSeries)

						# add entry at position idx, jdx
						occuMatrix[idx, jdx] = (ijElement)

						# add same entry at the tranpose position because the matrix is symmetric
						occuMatrix[jdx, idx] = occuMatrix[idx, jdx]

			if arg_verbose >= 2: 
				Utils.printflush('|')	
				

		# diagonlaize the occupancy matrix 
		lambdasPhi, eigVectorsPhi  = Utils.diagonalize(occuMatrix)
		
		# normalize the eig values with number of states and return the absolute value
		lambdasPhi = nmp.abs(nmp.divide(lambdasPhi, vecOrder))

		# is the occupancy matrix symmetric-positive definite? (are all the eigen values positive?)
		for iLm, lm in enumerate(lambdasPhi):
			Utils.printOut(arg_outFile, "Eigen value {} = {}".format(iLm, lm))

		# compute residue topog. entropy from the eigen values using the `lm.log(lm)` formalism
		ridTopogEntropy4 = 0
		for lm in filter(lambda x: x != 0, lambdasPhi):
			ridTopogEntropy4 += (lm * nmp.log(lm) )

		ridTopogEntropy4 *= -UAC.GAS_CONST #(R)

		# Final residue entropy information	
		Utils.printflush('{:<40s} : {:.4f}'.format('Topog. Entropy using method4 ({} {})'.format(arg_baseMolecule.resnameArray[rid], arg_baseMolecule.residArray[rid]), ridTopogEntropy4))
		Utils.printflush('-'*60)

		Utils.printOut(arg_outFile, '{:<40s} : {:.4f}'.format('Topog. Entropy using method4 ({} {})'.format(arg_baseMolecule.resnameArray[rid], arg_baseMolecule.residArray[rid]), ridTopogEntropy4))
		Utils.printOut(arg_outFile, '-'*60)

		# add this residue's topog. entropy to the total topog. entropy
		totalTopogEntropy4 += ridTopogEntropy4
		
	# print out the outputs
	if arg_verbose >= 0:
		Utils.printflush('{:<40} : {:>15.3f}'.format('Topog. Entropy (Method4) ', totalTopogEntropy4))
		Utils.printflush('-'*60)

	Utils.printOut(arg_outFile, '{:<40} : {:>15.3f}'.format('Topog. Entropy (Method4) ', totalTopogEntropy4))
	Utils.printOut(arg_outFile, '-'*60)
		
	return
#END



def compute_topographical_entropy_method3(arg_baseMolecule, arg_hostDataContainer, arg_outFile, arg_verbose):

	# number of frames
	numFrames = len(arg_hostDataContainer.trajSnapshots)

	# conformation vector order |g+, g-, t>
	vecOrder = 3   # (= Q)

	# treat each dihedral as a conformation entity
	# initialize a list of ConformationEntities for this molecule
	conformationEntityList = []

	# fetch all the heavy dihedrals
	nohDiheds = list(filter(lambda dih:  dih.is_heavy_dihedral(), arg_baseMolecule.dihedralArray))
	
	# for iDih in arg_baseMolecule.dihedralArray:
	for iDih in nohDiheds:
		dihAtoms = {"atom1": iDih.atom1, 
		            "atom2":     iDih.atom2, 
		            "atom3":     iDih.atom3, 
		            "atom4":     iDih.atom4,
		            "isBB" :     iDih.is_BB_dihedral(),
		            "isHeavy" :  iDih.is_heavy_dihedral(),
		            "isSameRes" : iDih.is_from_same_residue()}
			
		# make an entity from this dihedral
		newEntity = CONF.ConformationEntity(arg_order = vecOrder, arg_numFrames = numFrames, **dihAtoms)

		# generate a time series of the conformations it acquires.
		# at each frame
		for iFrame in range(numFrames):

			# fetch the dihedral value at that frame
			phi = iDih.get_dihedral_angle_lab(arg_dataContainer = arg_hostDataContainer, arg_frame = iFrame)

			# define its status
			isGaucheP = ( 0 <= phi < 120)
			isGaucheN = ( 0 > phi >= -120 )
			isTrans   = ( phi >= 120 or phi < -120)

			# place it in the time series block appropriately
			newEntity.timeSeries[:,iFrame] = nmp.asarray([isGaucheP, isGaucheN, isTrans], dtype = nmp.int8)

		# add this dihedral into the list of conformation entities
		conformationEntityList.append(newEntity)

	
	# total number of conformational entities (or dihedrals)
	numDiheds = len(conformationEntityList)

	# for each pair of dihedrals, find a matrix \rho_ij = \p_ij * \r_ij for i,j = 1 .. Q
	# where \p_ij is the probability of seeing dihedral1 in state 'i' and dihedral 2 in state 'j'
	# and   \r_ij is the correlation of dihedral1 in state 'i' and dihedral 2 in state 'j'

	# initialize a density matrix with values that can never be!
	densityMatrix = -1000 * nmp.zeros((numDiheds*vecOrder, numDiheds*vecOrder))

	for i in range(0,numDiheds):
		iEntity = conformationEntityList[i]
		Utils.printflush('Dihedral {} : |'.format(i), end = ' ' )	

		for j in range(i, numDiheds):
			jEntity = conformationEntityList[j]
			Utils.printflush('.',end='')

			Utils.printOut(arg_outFile, 'Dihedral {}: ({} {} {} {}) and Dihedral {}: ({} {} {} {})'.format(i, iEntity.atom1, iEntity.atom2, iEntity.atom3, iEntity.atom4, \
				j, jEntity.atom1, jEntity.atom2, jEntity.atom3, jEntity.atom4))

			for iState in range(vecOrder):
				idx = (vecOrder * i) + iState
				iDihedralTimeSeries = iEntity.timeSeries[iState,:]
				iDihedralTimeSeriesSTD = nmp.std(iDihedralTimeSeries)

				for jState in range(vecOrder):
					jdx = (vecOrder * j) + jState
					jDihedralTimeSeries = jEntity.timeSeries[jState,:]
					jDihedralTimeSeriesSTD = nmp.std(jDihedralTimeSeries)

					# correlation (r_ij)
					ijCorrelation = -1000    #initialize with a number that can never be!

					if iDihedralTimeSeriesSTD == 0:
						if jDihedralTimeSeriesSTD == 0:
							#both are not changing => correlation is '1'
							ijCorrelation = 1
						elif jDihedralTimeSeriesSTD != 0:
							#one is changing irrespective of the other => no correlation
							ijCorrelation = 0

					elif iDihedralTimeSeriesSTD != 0:
						if jDihedralTimeSeriesSTD == 0:
							#one is changing irrespective of the other => no correlation
							ijCorrelation = 0
						else:
							#compute the correlation using covariance
							ijCovariance = CF.covariance(iDihedralTimeSeries, jDihedralTimeSeries)
							ijCorrelation = ijCovariance/(iDihedralTimeSeriesSTD * jDihedralTimeSeriesSTD)

					# probability of coexistence (p_ij)
					ijProb = CF.probability_of_coexistence(iDihedralTimeSeries, jDihedralTimeSeries)
					
					# add entry at position idx, jdx
					densityMatrix[idx, jdx] = ijProb * ijCorrelation

					# add same entry at the tranpose position because the matrix is symmetric
					densityMatrix[jdx, idx] = densityMatrix[idx, jdx]

					Utils.printOut(arg_outFile, "{:>15.8f}".format(densityMatrix[idx, jdx]), end = "")

					if jState == (vecOrder - 1):
						Utils.printOut(arg_outFile,'')
		
		Utils.printflush('|')	
			
	# filter rows and columns with all zero (which make the matrix singular)
	densityMatrix = CF.filter_zero_rows_columns(densityMatrix)
	
	# diagonlaize the density matrix 
	lambdasRho, eigVectorsRho  = Utils.diagonalize(densityMatrix)

	# is the density matrix symmetric-positive definite?
	for lr in lambdasRho:
		Utils.printOut(arg_outFile, lr)
	

	# plot the matrix with imshow
	if False:
		mplot = plt.figure()
		ax = mplot.add_axes([0, 0, 1, 1], frameon=False, aspect=1)
		plt.imshow(densityMatrix, cmap = "jet", vmin = -1, vmax = +1)
		plt.show()

	return
#END

def get_avg_hpos(arg_atom, arg_frame, arg_baseMolecule, arg_hostDataContainer):
	"""
	Compute the average of the coordinates of the hydrogen
	atoms covalently bonded to the atom with index iAtom in a 
	given point in time (arg_frame) and return the value. 
	If no hydrogen is bonded to it, return a 
	random value for 3D cartesian coordinates.
	"""
	avgHPos = nmp.zeros((3))
	numH = len(arg_baseMolecule.bondedHydrogenTable[arg_atom])

	if numH != 0:
		for iPriorityH, iH in arg_baseMolecule.bondedHydrogenTable[arg_atom].list_in_order():
			iHPosition = arg_hostDataContainer._labCoords[arg_frame, iH]
			avgHPos = nmp.add(avgHPos, iHPosition)

		avgHPos /= numH

	else:
		# assign random position because 
		# eventually the only atom using that 
		# NB: basis will be the heavy atom which 
		# simply lies on the origin
		avgHPos =  nmp.random.random(3)

		# transform the average H position to a 
		# coordinate system whose origin is the position of 
		# the heavy atom.
		avgHPos = avgHPos - arg_hostDataContainer._labCoords[arg_frame, arg_atom]

	return avgHPos
#END

def calculate_entropy_per_dof(arg_frequencies):
	"""
	For each frequency that corresponds to a given dof, 
	it computes the entropy
	using eqn (4) in the FTCov paper and returns it
	"""

	
	exponent = UAC.PLANCK_CONST*arg_frequencies/UAC.kT2J
	
	expTermPositive = nmp.power(nmp.e, exponent)
	expTermNegative = nmp.power(nmp.e, -exponent)
	
	
	DOFEntropy = exponent/(expTermPositive - 1)
	DOFEntropy -= nmp.log(1 - expTermNegative)
	DOFEntropy *= UAC.GAS_CONST
	
	return DOFEntropy
# END

def compute_frequency_from_lambda(arg_lambdas):
	""" 
	For each lambda, compute the frequency.
	F = sqrt(λ/kT)/2π 
	"""
	return nmp.sqrt((arg_lambdas) * UAC.ONE_OVER_KT2J)/(2*nmp.pi)
#END


def compute_ampfac_from_lambda(arg_lambdas):
	"""
	For each mode (lambda), the amplitude factor is computed.
	Amplitude 
	A_i = kT/sqrt(L_i) for all 'i' in 1:num. modes
	Units of A_i: Ang/sqrt(amu)
	Ref: Macromolecule entropy from force, R. Henchman JCTC 2014
	"""
	return nmp.divide(UAC.kT2J, nmp.sqrt(arg_lambdas))
#END
