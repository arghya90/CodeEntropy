#units:

NM2ANG = 10.
AMU2KG = 1.66053892110e-27
N_AVOGADRO = 6.0221415e+23
GAS_CONST= 8.3144598484848  # J/mol/K
PLANCK_CONST = 6.62607004081818e-34  #J s
ANG2M = 1e-10
NM2M = 1e-9
C_LIGHT = 29979245800 #cm/s
temperature = 298 #K
kT2J = 4.11e-21 * temperature/298
ONE_OVER_KT2J = 1e+21*(298/(4.11 * temperature))

AKMA2PS = 4.88882129e-02

def change_lambda_units(arg_lambdas):
    """Unit of lambdas : kJ2 mol-2 A-2 amu-1
    change units of lambda to J/s2"""
    # return arg_lambdas * N_AVOGADRO * N_AVOGADRO * AMU2KG * 1e-26
    return arg_lambdas * 1e+29 / N_AVOGADRO

