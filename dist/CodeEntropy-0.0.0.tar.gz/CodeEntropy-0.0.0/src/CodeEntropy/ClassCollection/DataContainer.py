import numpy as nmp
import sys

from CodeEntropy.Trajectory import TrajectoryFrame as TF

class DataContainer(object):
	""" This is the main data container that has the framewise information of
	positions and forces on all the atoms, in lab and local frames. The vectors
	in the local frames are obtained after transforming the lab frame vectors 
	using orthonormal bases that also stored framewise for each atom. 

	The properties of its molecule (base molecule) is linked to a molecule class object
	that contains the info about its topology. """

	def __init__(self):
		
		self.molecule = None
		self.numFrames = -1
		self.frameIndices = []     # a list of integer values
		self.trajSnapshots = []  # a list of instances of TrajectoryFrame class
		
	def print_attributes(self):
		# print("{:<20s} : {}".format("Molecule name", self.molecule.name))
		print("{:<20s} : {}".format("Number of atoms", self.molecule.numCopies * self.molecule.numAtomsPerCopy))
		print("{:<20s} : {}".format("Number of frames", len(self.trajSnapshots)))
		
		return
  
	def initialize_ndarrays(self):
		
		""" The number of frames for which the container will hold the data must be provided before hand"""
		assert(len(self.trajSnapshots) >= 0 and len(self.frameIndices) == len(self.trajSnapshots))

		self._labCoords = nmp.ndarray( (len(self.trajSnapshots), self.molecule.numCopies * self.molecule.numAtomsPerCopy, 3) )
		self._labForces = nmp.ndarray( (len(self.trajSnapshots), self.molecule.numCopies * self.molecule.numAtomsPerCopy, 3) )
		
		self.translationAxesArray = nmp.ndarray ( (len(self.trajSnapshots), self.molecule.numCopies * self.molecule.numAtomsPerCopy, 1+3, 3) ) # 4rth row is the origin
		self.rotationAxesArray = nmp.ndarray ( (len(self.trajSnapshots), self.molecule.numCopies * self.molecule.numAtomsPerCopy, 1+3, 3) ) # 4rth row is the origin

		self.localCoords = nmp.ndarray( (len(self.trajSnapshots), self.molecule.numCopies * self.molecule.numAtomsPerCopy, 3) )
		self.localForces = nmp.ndarray( (len(self.trajSnapshots), self.molecule.numCopies * self.molecule.numAtomsPerCopy, 3) )
		self.localTorques = nmp.ndarray( (len(self.trajSnapshots), self.molecule.numCopies * self.molecule.numAtomsPerCopy, 3) )

		
		return
		
	def reset_translationAxesArray(self):
		self.translationAxesArray = nmp.ndarray ( (len(self.trajSnapshots), self.molecule.numCopies * self.molecule.numAtomsPerCopy, 4, 3) )
		return
	
	def reset_rotationAxesArray(self):
		self.rotationAxesArray = nmp.ndarray ( (len(self.trajSnapshots), self.molecule.numCopies * self.molecule.numAtomsPerCopy, 4, 3) )
		return

	def update_translationAxesArray_at(self, arg_frameIndex, arg_atomList, arg_pAxes):

		assert(len(arg_atomList) * 3 == len(arg_pAxes))
		self.translationAxesArray[arg_frameIndex,arg_atomList][0:3,] = arg_pAxes	   
		return
	
	def update_rotationAxesArray_at(self, arg_frameIndex, arg_atomList, arg_pAxes):

		assert(len(arg_atomList) * 3 == len(arg_pAxes))
		self.rotationAxesArray[arg_frameIndex,arg_atomList][0:3,] = arg_pAxes	   
		return
	
	def update_localCoords_of_all_atoms(self, arg_type):
		if arg_type.upper() not in ["T","R"]:
			raise ValueError('Type {} for axes system does not exist. Chose T(translation) or R(rotation)'.format(arg_type))
			return
		
		if arg_type.upper() == "T":
			for iFrame in range(len(self.trajSnapshots)):
				for iAtom in range(self.molecule.numCopies * self.molecule.numAtomsPerCopy):
					#translation
					self.localCoords[iFrame,iAtom] = self._labCoords[iFrame,iAtom] - self.translationAxesArray[iFrame,iAtom][-1,]
					self.localCoords[iFrame,iAtom] = self.translationAxesArray[iFrame,iAtom][0:3,] @ self.localCoords[iFrame,iAtom]
		elif arg_type.upper() == "R":
			for iFrame in range(len(self.trajSnapshots)):
				for iAtom in range(self.molecule.numCopies * self.molecule.numAtomsPerCopy):
					#rotation
					self.localCoords[iFrame,iAtom] = self._labCoords[iFrame,iAtom] - self.rotationAxesArray[iFrame,iAtom][-1,]
					self.localCoords[iFrame,iAtom] = self.rotationAxesArray[iFrame,iAtom][0:3,] @ self.localCoords[iFrame,iAtom]

		return
	
	def update_localForces_of_all_atoms(self, arg_type):
		if arg_type.upper() not in ["T","R"]:
			raise ValueError('Type {} for axes system does not exist. Choose T(translation) or R(rotation)'.format(arg_type))
			return
	
		if arg_type.upper() == "T":
			for iFrame in range(len(self.trajSnapshots)):
				for iAtom in range(self.molecule.numCopies * self.molecule.numAtomsPerCopy):
					self.localForces[iFrame, iAtom] = self.translationAxesArray[iFrame, iAtom][0:3,] @ self._labForces[iFrame, iAtom]
		elif arg_type.upper() == "R":
			for iFrame in range(len(self.trajSnapshots)):
				for iAtom in range(self.molecule.numCopies * self.molecule.numAtomsPerCopy):
					self.localForces[iFrame, iAtom] = self.rotationAxesArray[iFrame, iAtom][0:3,] @ self._labForces[iFrame, iAtom]
								
		return


#END

