import numpy as nmp
from  CodeEntropy.FunctionCollection import Utils

class Mode(object):
	"""
	A class that contains information about a 
	fundamental mode of motion.
	"""

	def __init__(self, arg_modeIdx = 0, arg_modeEval = -1,\
	             arg_modeEvec = [], arg_modeFreq = -1,  **kwargs):
		self.modeIdx = arg_modeIdx
		self.modeEval = arg_modeEval
		self.modeEvec = arg_modeEvec
		self.modeFreq = arg_modeFreq

		for k, v in kwargs.items():
			setattr(self, k, v)

		self.modeLength = None

	#END

	def __lt__(self, otherMode):
		return self.modeFreq < otherMode.modeFreq

	def __gt__(self, otherMode):
		return self.modeFreq > otherMode.modeFreq

	def __eq__(self, otherMode):
		return self.modeFreq == otherMode.modeFreq

	def set_mode_length(self, arg_freq):
		"""
		set the inverse of the square root of the mode frequency
		as the mode length (used for NMD format output)
		"""

		try:
			self.modeLength = nmp.sqrt(1/arg_freq)
		except ValueError:
			Utils.printflush("Invalid frequency value for the mode.")
			return
	#END

	def get_mode_info(self):
		""" returns a string containing the mode info in the format
		suitable for NMWiz """

		# mode - Normal mode array. Each normal mode array must be provided 
		# in one line as a list of decimal numbers. 
		# Mode array may be preceded by mode index and mode length 
		# (square root of variance or inverse frequency). 
		#
		# Mode %d %.2f x3 x3 ... x3

		retStr = "Mode {:d} {:.2f} ".format(self.modeIdx, self.modeLength)
		for u in self.modeEvec:
			retStr = "{} {:.3f}".format(retStr, u)

		return retStr
	#END