import numpy as nmp
import sys
from collections import deque

import CodeEntropy.FunctionCollection as FC

class LinkedListNode(object):
	def __init__(self, arg_value):
		self.value = arg_value
		self.nextNode = None

	def __eq__(self, arg_otherNode):
		return self.value == arg_otherNode.value

class DoublyLinkedListNode(LinkedListNode):
	def __init__(self, arg_value):
		super().__init__(arg_value)
		self.previousNode = None

	def __iter__(self):
		return self

class CircularLinkedList(object):
	""" A linked list where each node is connected to its next node and the last node is linked with the first node,
	thus completing a circle"""

	def __init__(self):
		self.currentPosition = None
		self.startPosition = None
		self.count = 0

	def append(self, arg_node):
		if self.count == 0:
			self.startPosition = arg_node
			self.currentPosition = arg_node
			arg_node.nextNode = self.currentPosition
			self.incr_count()

		else:
			self.currentPosition.nextNode = arg_node
			self.currentPosition = arg_node
			arg_node.nextNode = self.startPosition
			self.incr_count()

		return

	def incr_count(self):
		self.count += 1
		return

	def reset_position(self):
		self.currentPosition = self.startPosition
		return

	def __len__(self):
		return self.count

	def get_current_position(self):
		return self.currentPosition

	def move_right_of_current_position(self):
		self.currentPosition = self.currentPosition.nextNode
		return
#END

class DoublyLinkedList(object):
	""" Each node is connected to its next and previous node."""
	def __init__(self):
		self.startPosition = None
		self.endPosition = None
		self.currentPosition = None
		self.count = 0


	def append(self, arg_doubleNode):
		if self.count == 0:
			# means it points to nothing
			# initialize it now
			self.startPosition = arg_doubleNode
			self.endPosition = arg_doubleNode
			self.currentPosition = arg_doubleNode
			self.incr_count()

		else:
			# add it to the right of the currently last position
			self.endPosition.nextNode = arg_doubleNode
			self.endPosition = arg_doubleNode
			self.currentPosition = self.endPosition
			self.incr_count()

		return

	def incr_count(self):
		self.count += 1
		return

	def decr_count(self):
		self.count -= 1
		assert(self.count >= 0)
		return

	def __len__(self):
		return self.count

	def get_current_position(self):
		return self.currentPosition

	def get_node_at(self, arg_index):
		#0-indexed
		try:
			assert(arg_index < self.count and arg_index >= 0)
		except:
			raise IndexError('{} exceeds the last index of the list ({})'.format(arg_index, self.count - 1))
		
		# backup the current postion
		backupCurrentPosition = self.get_current_position()

		idx = 0
		self.move_to_start()
		idxNode = self.get_current_position()
		while idx != arg_index:
			idxNode = idxNode.nextNode
			idx += 1

		self.currentPosition = backupCurrentPosition
		return idxNode


	def move_to_start(self):
		self.currentPosition = self.startPosition
		return 1

	def move_to_end(self):
		self.currentPosition = self.endPosition
		return 1

	def move_right_of_current_position(self):
		self.currentPosition = self.currentPosition.nextNode
		return 

	def move_left_of_current_position(self):
		self.currentPosition = self.currentPosition.previousNode
		return 

	def remove_node_and_move_right(self):
		""" Remove the node pointed by the currentPosition and then move to its nextNode """
		leftNode = self.currentPosition.previousNode
		rightNode = self.currentPosition.nextNode

		if leftNode != None:
			leftNode.nextNode = rightNode
		if rightNode != None:
			rightNode.previousNode = leftNode

		self.currentPosition = rightNode
		self.decr_count()
		return 1

	def remove_node_and_move_left(self):
		""" Remove the node pointed by the currentPosition and then move to its previousNode """
		leftNode = self.currentPosition.previousNode
		rightNode = self.currentPosition.nextNode

		if leftNode != None:
			leftNode.nextNode = rightNode
		if rightNode != None:
			rightNode.previousNode = leftNode

		self.currentPosition = previousNode
		self.decr_count()
		return 1

	def clear_all(self):
		""" Basically, point all its memebr pointers to None and reset its count to 0 """
		self.startPosition = None
		self.endPosition = None
		self.currentPosition = None
		self.count = 0
		return


	def iterator(self):
		assert(self.count != 0)

		self.move_to_start()
		while self.currentPosition:
			yield self.currentPosition
			self.move_right_of_current_position()

#END

class TreeNode(object):
	""" A generic data structure that depicts a node for a binary tree. 
	Has a pointer to one parent and 2 children """

	def __init__(self, arg_leftChildNode, arg_rightChildNode, arg_value):
		self.leftChildNode = arg_leftChildNode
		self.rightChildNode = arg_rightChildNode
		self.value = arg_value

	def __lt__(self, arg_otherNode):
		assert(self.value != None and arg_otherNode.value != None)
		return self.value < arg_otherNode.value

	def __gt__(self, arg_otherNode):
		assert(self.value != None and arg_otherNode.value != None)
		return self.value > arg_otherNode.value

#END

class BinaryTree(object):
	""" A rooted bindary tree which will be defined by a root tree node. It will be populated by links 
	to the root nodes and their subsequent links"""
	def __init__(self):
		self.rootNode = None
		self.nodeCount = 0

	def __len__(self):
		return self.nodeCount
	#END


	def add_node(self, arg_node):
		if self.rootNode == None:
			# arg_node is the root, add it likewise
			self.rootNode = arg_node
			self.incr_nodeCount()
			return

		else:
			self.add_node_to_rooted_tree(arg_parentNode = self.rootNode, arg_node = arg_node)
			return
	#END

	def add_node_to_rooted_tree(self, arg_parentNode, arg_node):
		if arg_node < arg_parentNode:
			if arg_parentNode.leftChildNode == None:
				arg_parentNode.leftChildNode = arg_node
				arg_node.parentNode = arg_parentNode
				self.incr_nodeCount()
				return
			else:
				self.add_node_to_rooted_tree(arg_parentNode = arg_parentNode.leftChildNode, arg_node = arg_node)

		elif arg_node > arg_parentNode:
			if arg_parentNode.rightChildNode == None:
				arg_parentNode.rightChildNode =arg_node
				arg_node.parentNode = arg_parentNode
				self.incr_nodeCount()
				return
			else:
				self.add_node_to_rooted_tree(arg_parentNode = arg_parentNode.rightChildNode, arg_node = arg_node)

	def list_in_order(self):
		outList = []
		try:
			assert(self.rootNode != None)
		except:
			# print('Tree is non-existent. It will return an empty list')
			return outList

		self.generate_IN_order_list_from_node(arg_node = self.rootNode, arg_outList = outList)
		return outList

	#END	



	def generate_IN_order_list_from_node(self, arg_node, arg_outList):
		if arg_node.leftChildNode == None:
			pass
		else:
			self.generate_IN_order_list_from_node(arg_node = arg_node.leftChildNode, arg_outList = arg_outList)

		arg_outList.append(arg_node.value) 

		if arg_node.rightChildNode == None:
			pass
		else:
			self.generate_IN_order_list_from_node(arg_node = arg_node.rightChildNode, arg_outList = arg_outList) 

		return arg_outList
	#END


	
	def incr_nodeCount(self):
		self.nodeCount += 1
		return

	#END

	def decr_nodeCount(self):
		self.nodeCount -= 1
		return
	#END

#END

class ResidueChecker(object):
	""" A class that can be used to decipher the topology of the side chain of the residue. The idea is to redduce the number of flops 
	that are used to obtain atomic pairwise distances """

	def __init__(self):
	    self.vLevels = ["A","B","G","D","E","Z","H"]
	    self.hLevels = [n for n in range(-2,3)]

	    # to be used for heapifying bonded atomlists
	    self.priorityDict = {"A" : 0,
	    					 "B" : 1,
	    					 "G" : 2,
	    					 "D" : 3,
	    					 "E" : 4,
	    					 "Z" : 5,
	    					 "H" : 6}
	    
	    # useful information
	    self.minHLevel = min(self.hLevels)
	    self.maxHLevel = max(self.hLevels)
	    
	    # to navigate through the vertical levels
	    self.nextVLevel = dict((self.vLevels[i], self.vLevels[i+1]) for i in range(len(self.vLevels) - 1))
	    
	    # initialize
	    self.generate_checker()
	    
	    # list of present atoms
	    self.memberAtoms = []
	    
	    # tuples of bonded atoms found from running its topology calculator 
	    self.covalentBondList = []
	    
	    return
	#END

	def generate_checker(self):
	    self.checker = dict()
	    for v in self.vLevels:
	        self.checker[v] = dict()
	        for h in self.hLevels:
	            self.checker[v][h] = ("_", -1)
	    return
	#END

	def reset_checker(self):
	    for v in self.vLevels:
	        for h in self.hLevels:
	            self.checker[v][h] = ("_", -1)
	    return
	#END

	def print_checker(self):
	    # each legit element is a tuple (atomName, atomID)
	    # print the atomName only
	    for v in self.vLevels:
	        print("{} > ".format(v), end = '')
	        for h in self.hLevels:
	            print("{:^5}".format(self.checker[v][h][0]), end=' ')
	        print()
	    return
	#END

	def assign_position_to_atom(self, arg_atomName, arg_atomId): 
	    #artificially stretch atomNAme (only 3 atom letter accepted)
	    arg_atomName = "{:<3s}".format(arg_atomName)

	    # e.g. CG1 -> C G 1
	    element = arg_atomName[0]
	    vPos = arg_atomName[1]
	    hPos = arg_atomName[2]
	    
	    try:
	        if hPos == " ":
	            hPos = 0
	        elif int(hPos) == 1:
	            hPos = -1
	        elif int(hPos) > 1:
	            hPos = int(hPos) - 1
	    except:
	        raise ValueError('horizontal position cannot be determined for {}'.format(arg_atomName))
	    
	    
	    self.checker[vPos][hPos] = (arg_atomName, arg_atomId)
	    self.memberAtoms.append(arg_atomName)
	    return
	#END

	def isPresent(self, arg_atomName):
	    # to validate the argument to other member functions
	    arg_atomName = "{:<3s}".format(arg_atomName)
	    return arg_atomName in self.memberAtoms
    #END

	def get_vertical_level(self, arg_atomName):
	    if self.isPresent(arg_atomName):
	        arg_atomName = "{:<3s}".format(arg_atomName)
	        vPos = arg_atomName[1]
	        if vPos not in self.vLevels:
	            print("vLevel = '{}' ({})".format(vPos, "This level does not exist"))
	            return
	        else:
	             return vPos
            
	    else:
	        raise ValueError('{} was not found. It was likely never assigned a position'.format(arg_atomName))
	#END
        
	def get_horizontal_level(self,arg_atomName):
	    if self.isPresent(arg_atomName):
	        #a valid horizontal level must be an integer
	        arg_atomName = "{:<3s}".format(arg_atomName)
	        hPos = arg_atomName[2]
	        
	        try:
	            if hPos == " ":
	                hPos = 0
	            elif int(hPos) == 1:
	                hPos = -1
	            elif int(hPos) > 1:
	                hPos = int(hPos) - 1
	        except:
	            raise ValueError('horizontal position cannot be determined for {}'.format(arg_atomName))
	    
	            
	        if hPos not in self.hLevels:
	            print("hLevel = '{}' ({})".format(vPos, "This level does not exist"))
	            return
	        else:
	             return hPos
	            
	    else:
	        raise ValueError('{} was not found. It was likely never assigned a position'.format(arg_atomName))
	#END

	def get_next_vertical_level(self, arg_atomName):
	    # return the next vertical level if it exists
	    if self.isPresent(arg_atomName):
	        try:
	            presentLevel = self.get_vertical_level(arg_atomName)
	            return self.nextVLevel[presentLevel]
	        except:
	            print("Level {} doesn't exist or does not have a next level".format(presentLevel)) 
	            return
	    
	    else:
	        raise ValueError('{} was not found. It was likely never assigned a position'.format(arg_atomName))
	#END

	    
	def get_horizontal_search_limit(self, arg_atomName):
	    # based on its current hLevel, its zone of searching a horizontal level is returned
	    hPos = self.get_horizontal_level(arg_atomName)
	    if hPos == 0:
	        return self.hLevels
	    elif hPos < 0:
	        return [hl for hl in range(self.minHLevel,1)]
	    elif hPos > 0:
	        return [hl for hl in range(self.maxHLevel+1)]
	#END
	    
	def generate_topology(self, arg_rootAtomName, arg_rootAtomId):
	    # the core of this class
	    
	    # initialize a deque
	    rDeque = deque()
	    
	    rootTuple = (arg_rootAtomName, arg_rootAtomId)
	    rDeque.append(rootTuple)
	    
	    # a Breadth first approach to detect bonds between the atoms assigned to the checker
	    while len(rDeque) != 0:
	        parentTuple = rDeque.popleft()
	        parentAtomName, parentAtomId = parentTuple 
	        parentPriorityLevel = self.priorityDict[self.get_vertical_level(parentAtomName)]
	        
	        childSearchLimit = self.get_horizontal_search_limit(parentAtomName)
	        childrenVLevel = self.get_next_vertical_level(parentAtomName)
	        
	        childrenCount = 0
	        childrenHPositions = []
	        if childrenVLevel != None:
	            for jH in childSearchLimit:
	                if self.checker[childrenVLevel][jH][1] != -1:
	                    # means there is some information of value there
	                    childrenCount += 1
	                    childrenHPositions.append(jH)
	        else:
	            continue
	                    
	        # If more than one child found for a non-centered parent, non-existent bonds 
	        # may be wrongly added. So add a flag that tells the acceptor of the return value
	        # to check the distance between the atoms in the tuple and accept it only if the
	        # atom distances suggest that they might be covalently bonded
	        if childrenCount > 1 and self.get_horizontal_level(parentAtomName) != 0:
	            acceptFlag = False
	        else:
	            acceptFlag = True
	            
	        for jH in childrenHPositions:
	            childTuple = self.checker[childrenVLevel][jH]
	            childAtomName, childAtomId = childTuple
	            childPriorityLevel = self.priorityDict[childrenVLevel]

	            # append a 5-tuple (parentPriorityLevel, parentAtomId, childPriorityLevel, childAtomId, acceptFlag)
	            self.covalentBondList.append( (parentPriorityLevel, parentAtomId, childPriorityLevel, childAtomId, acceptFlag) )

	            rDeque.append(childTuple)
	                
	    return
	#END
	      
#END


