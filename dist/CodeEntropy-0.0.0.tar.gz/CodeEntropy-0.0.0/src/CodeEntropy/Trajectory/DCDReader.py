""" This is a DCD format trajectory file reader. This is the most basic working version.
The code architcrue was obtianed from NAMD's dcdlib.C file in its source code.

NOTE TO DEVELOPERS: 
Due to the difference in the time between when the code for reding TRR and DCD (this one), severe changes in the coding style 
can be seen. At the time this was being written, efforts were made to make the two readers as consistent as possible. """

import struct
import os, sys
import numpy as nmp

from CodeEntropy.Trajectory import TrajectoryFrame as TF
from CodeEntropy.Trajectory import TrajectoryConstants as TCON

class DCDTrajectory(object):
    """ A class that reads CHARMM/NAMD trajectory in DCD format. 
    
    In the DCD file, every block has an integer that starts it and the same integer that marks
    its end. this integer is the bytesize or size of that block, i.e. the number of bytes of information
    to be expected till before the end of the bloack is reached."""
    
    def __init__(self, arg_fileName, arg_beginTime, arg_endTime, arg_verbose):
        self.trajFile = arg_fileName
        self.numAtoms = -1
        self.numFixedAtoms = -1
        self.numFrames = -1
        self.timestep = -1
        self.hasCellInfo = False
        self.currentSeekerPosition = -1
        self.snapshots = []

        if arg_beginTime < 0:
            self.beginTime = 0
        else:
            self.beginTime = arg_beginTime #in ps
        
        if arg_endTime < 0:
            self.endTime = nmp.finfo(float).max  # set it to the maximum possible float
        else:
            self.endTime = arg_endTime  #in ps

        self.generate_frames(arg_verbose)

#END

    def generate_frames(self, arg_verbose = True):
        """ Generate instances of Snapshot Class by reading the trajectory in a DCD compatibe way """

        with open(self.trajFile, 'rb') as dcdFileHandler:
            self.bufferStr = dcdFileHandler.read()
            
        self.read_dcd_header()
        
        # read framewise coordinate data
        for iFrame in range(self.numFrames):
            # create an instance of Trajectory frame which will store 3D vectors
            newFrame = TF.TrajectoryFrame(arg_frameIndex = iFrame, arg_baseMolecule = '', arg_vectorDim = TCON.VECTORDIM)
            newFrame.set_numAtoms(self.numAtoms)
            
            print('Frame ', iFrame)
            self.read_dcd_step(self.currentSeekerPosition, newFrame)
#END      

            
    def read_dcd_header(self):
        """ Read the header information from the DCD file and return 0 if successful"""

        returnValue = 0
        currPos = 0
        ifmt = '{}i'.format(endianness)
        ffmt = '{}f'.format(endianness)
        
        ################################################################################
        # FIRST BLOCK
        ################################################################################
        startBlockSize, currPos = self.decode(ifmt, currPos)
        
        try:
            assert(startBlockSize == 84)
        except:
            print("Bad DCD File format.")
            returnValue = -1


        # look for the word "CORD"
        fmt = '{}4s'.format(endianness)
        try:
            magicStr, currPos = self.decode(fmt, currPos)
            assert( magicStr == b'CORD')
        except:
            print("Bad DCD File format.")
            returnValue = -2

        # number of set of coordinates (a.k.a frames)
        self.numFrames, currPos = self.decode(ifmt, currPos)
        print("DCD file has {} frame(s)".format(self.numFrames))

        # starting timestep
        startTimeStep, currPos = self.decode(ifmt, currPos)
        print("Trajectory starts at step {}".format(startTimeStep), end= ' ')

        # starting timestep
        frameInterval, currPos = self.decode(ifmt, currPos)
        print("with {} ps separation between frames".format(frameInterval))

        #skip 5 "blank" integers
        for i in range(5):
            randInt, currPos = self.decode(ifmt, currPos)

        # number of fixed atoms
        self.numFixedAtoms, currPos = self.decode(ifmt, currPos)
        print("{} atoms in the structure are fixed atoms".format(self.numFixedAtoms))

        # timestep (a.k.a delta)
        self.timestep, currPos = self.decode(ffmt, currPos)
        print('Timestep = {}fs '.format(self.timestep))

        # skip 10 "blank" integers
        for i in range(10):
            randInt, currPos = self.decode(ifmt, currPos)

        # end size of first block should be indicated by another '84' 
        # (probably indicating the number of bytes read so far)
        endBlocksize, currPos = self.decode(ifmt, currPos)
        try:
            startBlockSize == endBlocksize
        except:
            print("Bad DCD File format because of block size mismatch")
            returnValue = -3

        ################################################################################
        # TITLE BLOCK
        ################################################################################
        startBlockSize, currPos = self.decode(ifmt, currPos)
        print('Size of the title block = {}'.format(startBlockSize))

        try:
            assert((startBlockSize - 4)%80 == 0)
        except:
            print("Bad DCD File format.")
            returnValue = -4

        # numtitles
        numTitle, currPos = self.decode(ifmt, currPos)
        print('{} title(s) in the DCD file'.format(numTitle))

        # skip the file seeker by 80*numTitle chars from current file position
        # arg_fileHandler.seek(numTitle * 80, os.SEEK_CUR)
        currPos += (numTitle * 80)

        # ending size of title block
        endBlocksize, currPos = self.decode(ifmt, currPos)
        try:
            startBlockSize == endBlocksize
        except:
            print("Bad DCD File format because of block size mismatch")
            returnValue = -3


        ################################################################################
        # NUMBER OF ATOMS BLOCK
        ################################################################################
        startblockSize, currPos = self.decode(ifmt, currPos)
        print('Size of the atom number block = {}'.format(randInt))

        # number of atoms
        self.numAtoms, currPos = self.decode(ifmt, currPos)
        print('{} atom(s) in the DCD file'.format(self.numAtoms))

        # ending size of title block
        endBlocksize, currPos = self.decode(ifmt, currPos)
        try:
            startBlockSize == endBlocksize
        except:
            print("Bad DCD File format because of block size mismatch")
            returnValue = -5


        self.currentSeekerPosition = currPos
        return returnValue

#END

    
    def read_dcd_step(self, arg_startPos, arg_snapshot):
        """ Read the frame information from the DCD file and return 0 if successful"""
        
        returnValue = 0
        currPos = arg_startPos
        ifmt = '{}i'.format(endianness)
        ffmt = '{}f'.format(endianness)
        
        
        ################################################################################
        # CELL BLOCK
        ################################################################################
        startBlockSize, currPos = self.decode(ifmt, currPos)
        
        if startBlockSize == 48:
            print('Will skip the cell information block')
            self.hasCellInfo = True
            
            #skip the next 48 bytes
            currPos += 48
            
            # end the cell block
            endBlocksize, currPos = self.decode(ifmt, currPos)
            
            try:
                assert(startBlockSize == endBlocksize)
            except:
                print("Bad cell block entry.")
                return -1
            
            # inititiate the beginning of the next block of coordinate arrays
            startBlockSize, currPos = self.decode(ifmt, currPos)
            
            # coord array
            coordinates = nmp.zeros( (self.numAtoms, 3))
            
        ################################################################################
        # X Y Z BLOCK
        # CREATE INSTANCES OF SNAPSHOT CLASS USING THE INFORMATION FETCHED HERE
        ################################################################################
        if startBlockSize == 4 * self.numAtoms:
            
            try:
                # starting  x-block
                print('About to read x for the next {} bytes'.format(startBlockSize))
                for idx in range(self.numAtoms):
                    x, currPos = self.decode(ffmt, currPos)
                    coordinates[idx, 0] = x

                endXBlock, currPos = self.decode(ifmt, currPos)
            except:
                print('Failed to read x values of atoms')
                returnValue = -11
                
            try:
                # starting  y-block
                print('About to read y for the next {} bytes'.format(startBlockSize))
                startYBlock, currPos = self.decode(ifmt, currPos)
                for jdx in range(self.numAtoms):
                    y, currPos = self.decode(ffmt, currPos)
                    coordinates[jdx, 1] = y

                endYBlock, currPos = self.decode(ifmt, currPos)
            except:
                print('Failed to read y values of atoms')
                returnValue = -12
                
            try:
                # starting  z-block
                print('About to read z for the next {} bytes'.format(startBlockSize))
                startZBlock, currPos = self.decode(ifmt, currPos)
                for kdx in range(self.numAtoms):
                    z, currPos = self.decode(ffmt, currPos)
                    coordinates[kdx, 2] = z

                endZBlock, currPos = self.decode(ifmt, currPos)
            except:
                print('Failed to read z values of atoms')
                returnValue = -13
            
            # print coordinates array
            print(coordinates)
            
        
        self.currentSeekerPosition = currPos
        return returnValue
#END

    def decode(self, arg_fmt, arg_startPos):
        """ Returns the first value in the unpacked tuple and the new position of the seeker. Use it for 
        unpacking one data at a time only."""
        
        sfmt = struct.calcsize(arg_fmt)
        val = struct.unpack(arg_fmt, self.bufferStr[arg_startPos: (arg_startPos  + sfmt)])
        newPos = arg_startPos + sfmt
        
        return (val[0], newPos)
