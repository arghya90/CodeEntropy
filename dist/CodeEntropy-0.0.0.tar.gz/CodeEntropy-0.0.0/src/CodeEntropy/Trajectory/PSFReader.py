""" This is a X-PLOR format PSF file reader """
__author__ = "Arghya Chakravorty"

import sys, os, re
import xdrlib
import numpy as nmp

from CodeEntropy.Trajectory import TrajectoryConstants as TCON
from CodeEntropy.ClassCollection import BaseMolecule as BM
from CodeEntropy.ClassCollection import BondStructs as BS

VECTORDIM = 3

class PsfAtomType(object):
    """ A class that stores the information about certain physical properties of a type of atom. the structure is designed to suit the information
    stored in a PSF file."""
    def __init__(self, arg_atomType, **kwargs):
        self.atomType = arg_atomType
        
        for prop, val in kwargs.items():
            setattr(self, prop, val)
#END

class PsfTopology(object):
    """ A class that reads X-PLOR or CHARMM format PSF file """

    def __init__(self, arg_fileName, arg_hostDataContainer):
        self.psfFile = arg_fileName
        self.hostDataContainer = arg_hostDataContainer   # the container where everything is stored

        # dictionary mapping residue indices with residue name
        # designed in order to appropriately populate residue based information (linked list format)
        # in the BaseMolecule instance
        self.residueDict= dict()

        # dictionary <int : PsfAtomType> of gromacs atomtypes
        self.psfAtomTypeDict = dict()

       
    def read_psfFile(self):
        """ Reads the input PSF file and returns an instance of BaseMolecule if successfully read"""

        # local variables
        isValidPSF = False
        canReadAtom = False
        canReadBond = False
        canReadAngle = False
        canReadDihed = False

        # create an instance of BaseMolecule
        # Unlike gromacs, everything is considered as one single molecule in PSF based packages
        newMolecule = BM.BaseMolecule(arg_name = '', arg_hostDataContainer = self.hostDataContainer)

        # for the sake of compatibility with information in gromacs's TPR file, add these information in 'newMolecule'
        # which are essentially dummies
        newMolecule.numCopies = 1


        # open file handler and read all the contents into a buffer
        with open(self.psfFile, 'r') as psfFileHandler:
            psfBuffer = psfFileHandler.readlines()

        i = 0
        while ( i <= len(psfBuffer)):

            # read the i-th line
            line = psfBuffer[i].strip()

            # skip blank lines
            if len(line) == 0:
                i += 1
                continue
                
            # look for "PSF" in the very first line
            if re.match("^PSF", line) and not isValidPSF:
                isValidPSF = True
                i += 1
                continue
                
            ######### REMARKS #########
            if re.match("^[0-9]+ !NTITLE$", line) and isValidPSF:
                searchRes = re.search("^([0-9]+) !NTITLE$", line)
                nTitles = int(searchRes.group(1))
                print('Found {} remark lines'.format(nTitles))
                i += (1 + nTitles)   # skip these many lines
                continue
            
            
            if re.match("^[0-9]+ !NATOM$", line) and not canReadAtom:
                canReadAtom = True
                searchRes = re.search("^([0-9]+) !NATOM$", line)
                nAtoms = int(searchRes.group(1))
                print('Expecting {} atoms in the system'.format(nAtoms))

                i += 1  
                continue
             
            ######### ATOMS #########   
            if canReadAtom:
                # read atom information
                if re.match("^[0-9]+\s+[0-9a-zA-Z]+\s+[0-9]+\s+[A-Za-z0-9]+\s+[a-zA-Z0-9]+\s+[a-zA-Z0-9]+\s+[0-9\.\-\+]+\s+[0-9\.]+", line):
                    # populate the basemolecule arrays with information being read here
                    searchRes = re.search("^([0-9]+)\s+([0-9a-zA-Z]+)\s+([0-9]+)\s+([A-Za-z0-9]+)\s+([a-zA-Z0-9]+)\s+([a-zA-Z0-9]+)\s+([0-9\.\-\+]+)\s+([0-9\.]+)", line)

                    # fetch atom information
                    # atom ID, segment name, residue ID, residue name, atom name, atom type, charge, mass, and an unused 0
                    atomIdx         = int(searchRes.group(1)) - 1   # must be 0-indexed
                    segName         = searchRes.group(2) 
                    atomResid       = int(searchRes.group(3)) - 1   # must be 0-indexed
                    atomResname     = searchRes.group(4)
                    atomName        = searchRes.group(5)
                    atomType        = searchRes.group(6)
                    atomCharge      = float(searchRes.group(7))
                    atomMass        = float(searchRes.group(8))

                    # populate residueDict
                    self.residueDict[atomResid] = atomResname

                    # populate atom-based indices of BaseMolecule instance
                    newMolecule.atomIndexArray.append(atomIdx)
                    newMolecule.atomResidueIdxArray.append(atomResid)
                    newMolecule.atomNameArray.append(atomName)
                    newMolecule.atomChargeArray.append(atomCharge)
                    newMolecule.atomMassArray.append(atomMass)


                # time to change flags to enable reading Bond information
                elif re.match("^[0-9]+ !NBOND", line):
                    canReadAtom = False
                    canReadBond = True
                    searchRes = re.search("^([0-9]+) !NBOND", line)
                    nBonds = int(searchRes.group(1))
                    print('Expecting {} bonds in the structure'.format(nBonds))

                    # Use this opportunity to 
                    # 1. fill residue index and name information
                    newMolecule.numAtoms = nAtoms
                    newMolecule.numAtomsPerCopy = newMolecule.numAtoms
                    newMolecule.numResidues = len(self.residueDict.keys())

                    for resid, resname in self.residueDict.items():
                        newMolecule.residArray.append(resid)
                        newMolecule.resnameArray.append(resname)
                    
                    # 2. correctly fill the cell-linked-list formatted residue information 
                    newMolecule.atomArray = nmp.zeros(newMolecule.numAtoms)
                    newMolecule.residueHead = -1 * nmp.ones(newMolecule.numResidues)

                    for aid, rid in zip(newMolecule.atomIndexArray, newMolecule.atomResidueIdxArray):
                        newMolecule.atomArray[aid] = newMolecule.residueHead[rid]
                        newMolecule.residueHead[rid] = aid


                    # 3. Also before fetching information about bonds, it needs to know the nature of the atoms involved in the bond.
                    # i.e. is it C, Ca, N, BB, H, etc.
                    # So now that all the atom inforamtion is supposed to have been read, use it to prepare these arrays in the 
                    # instance of BaseMolecule

                    # initialize
                    newMolecule.initialize_element_info_arrays()

                    # assign element types and priorities
                    newMolecule.populate_element_info_arrays()


                    # make a final check on the above assignments to the BaseMolecule instance
                    newMolecule.validate_assignments()

                i += 1
                continue
                
            ######### BONDS #########
            if canReadBond:
                # read bond information
                if re.match("^[0-9]+\s+[0-9]+", line):
                    # each line has at most 4 bond pairs
                    # print('Reading bond', line)
                    atomsInLine = line.split()
                    assert(len(atomsInLine) % 2 == 0 and 2 <= len(atomsInLine) <= 8)  # should have 2K (k=1, 2, 3 or 4) indices
                    jdx = 0
                    while jdx < len(atomsInLine):
                        aidI, aidJ = nmp.sort([ (int(atomsInLine[jdx + i]) - 1) for i in range(2) ])
                        newMolecule.add_bond_tree(arg_aidI=aidI, arg_aidJ=aidJ,arg_priorityLevelI=-1,arg_priorityLevelJ=-1)
                        jdx += 2
                    
            
                # time to change flags   
                elif re.match("^[0-9]+ !NTHETA", line):
                    canReadBond = False
                    canReadAngle = True
                    searchRes = re.search("^([0-9]+) !NTHETA", line)
                    nAngles = int(searchRes.group(1))
                    print('Expecting {} angles in the structure'.format(nAngles))
                    
                i += 1
                continue
        
            ######### ANGLES #########
            if canReadAngle:
                # read angle information
                if re.match("^[0-9]+\s+[0-9]+\s+[0-9]+", line):
                    # each line has at most 3 angle triplets
                    # print('Reading angle', line)
                    atomsInLine = line.split()
                    assert(len(atomsInLine) % 3 == 0 and 3 <= len(atomsInLine) <= 9)  # should have 3K (k=1,2 or 3) indices
                    
                    # do nothing because angle information is not used anywhere throughout
                    pass                   
             
                elif re.match("^[0-9]+ !NPHI", line):
                    canReadAngle = False
                    canReadDihed = True
                    searchRes = re.search("^([0-9]+) !NPHI", line)
                    nDiheds = int(searchRes.group(1))
                    print('Expecting {} dihedrals in the structure'.format(nDiheds))
                    
                i += 1
                continue
             
            ######### DIHEDRALS #########   
            if canReadDihed:
                # read dihedral information
                if re.match("^[0-9]+\s+[0-9]+\s+[0-9]+\s+[0-9]+", line):
                   
                    # each line has at most 2 dihedral quadruples
                    # print('Reading dihedral', line)
                    atomsInLine = line.split()
                    assert(len(atomsInLine) % 4 == 0 and 4 <= len(atomsInLine) <= 8)  # should have 4K (k=1 or 2) indices
                    
                    jdx = 0
                    while jdx < len(atomsInLine):
                        # the order of atom indices when reading dihedrals should not be changed (unlike bonds)
                        newDih = BS.Dihedral([ (int(atomsInLine[jdx + i]) - 1) for i in range(4) ], newMolecule)
                        newMolecule.add_dihedral(newDih)
                        jdx += 4
                
                elif re.match("^[0-9]+ !N", line):
                    canReadDihed = False

                i += 1
                continue


                
            ######### IGNORE EVERYTHING ELSE #########
            else:
                # if anything else shows up (like Improper, Cross-term, non-bonded params, etc. )
                # ignore them till the end of the PSF file
                #
                # Hopefully everything that is needed has been read in already!
                #
                break
        

        if (isValidPSF and nAtoms > 0 and nBonds > 0 and nAngles > 0 and nDiheds > 0):
            return newMolecule
        else:
            return None
#END

    
