import numpy as nmp
from CodeEntropy.Trajectory import (PSFReader)
from CodeEntropy.ClassCollection import DataContainer
from CodeEntropy.ClassCollection import CustomDataTypes as CDT
from CodeEntropy.ClassCollection import BondStructs
from CodeEntropy.FunctionCollection import Utils

########################################################################################################################################
# NOTE: SIGNIFICANT CHANGES IN THE FLOW OF STEPS AND VARIABLE ASSIGNMENT BECAUSE OF THE FUNDAMENTAL DIFFERENCE BETWEEN NAMD AND GROMACS
########################################################################################################################################
def read_charmm_input(arg_psfFile,\
                    arg_xdcdFile, \
                    arg_fdcdFile, \
                    arg_outFile, \
                    arg_beginTime, \
                    arg_endTime, \
                    srg_stride, \
                    arg_verbose = False ):
    
    """ 
    A function supplied with :
    1. input topology/structure (PSF) 
    2. a coordinate trajectory file from CHARMM (DCD).
    3. a force trajectory file from CHARMM (DCD).

    Separate DCD files are required because unlike GROMACS, CHARMM does
    not print forces in a trajectory. A charmm script to write a FORCE
    trajectory file must be obtianed.
    Function returns an instance of BaseMolecule and 
    DataContainer which are linked to each other.
    """

    # topology/PSF file
    Utils.printflush('{:<40s} : {}'.format('Reading PSF format topology file',arg_psfFile))
    topol = PSFReader.PsfTopology(arg_psfFile)

    # base molecule
    myProtein = topol.read_psfFile()

    if arg_verbose >= 0:
        Utils.printflush('{:<40s} : {}'.format('Number of atoms expected in trajectory', myProtein.numAtoms))


    # assign host heavy atoms for each hydrogen (needed for entropy calculation at UA level)
    myProtein.hostHeavyAtomArray = nmp.zeros(myProtein.numAtoms)
    for idx in myProtein.bondedHeavyAtomTable.keys():

        if myProtein.isHydrogenArray[idx]:
            # it must have ONE and ONLY ONE heavy atom bonded to it (it host heavy atom)
            try:
                assert(len(myProtein.bondedHeavyAtomTable[idx]) != 1)
            except :
                ValueError('Atom {} is a hydrogen with more or less than 1 covalent bonds ({})'.format(idx, len(myProtein.bondedHeavyAtomTable[idx])))

            # fetch that atom
            try:
                priority, heavyAtomIdx = myProtein.bondedHeavyAtomTable[idx].list_in_order()[0]
                myProtein.hostHeavyAtomArray[idx] = heavyAtomIdx
                myProtein.hostHeavyAtomArray[heavyAtomIdx] = heavyAtomIdx #self
            except:
                raise IndexError('Index {} is out of range'.format(idx))

    
    # define an object of DataContainer class
    mainContainer = DataContainer.DataContainer()
    mainContainer.molecule = myProtein


    ### READ TRAJECTORY (RELOCATE) ###
    # print('{:<40s} : {}'.format('Reading trajectory file',arg_trajFile))
    # # FC.CustomFunctions.printOut(arg_outFile,'{:<40s} : {}'.format('Trajectory file',arg_trajFile))
    
    # traj = TRRReader.GroTrajectory(arg_fileName = arg_trajFile, arg_beginTime = arg_beginTime, arg_endTime = arg_endTime, arg_verbose = arg_verbose)

    # # assign the snapshots read in traj to mainContainer's trajSnapshot 
    # mainContainer.trajSnapshots.clear_all()
    # mainContainer.frameIndices.clear_all()

    # frameIdx = 0
    # for iFrame in traj.snapshots.iterator():
    #     mainContainer.trajSnapshots.append(iFrame)
    #     mainContainer.frameIndices.append(CDT.DoublyLinkedListNode(arg_value=frameIdx))
    #     frameIdx += 1

    # mainContainer.print_attributes()

    # # read the coords and forces from the trajectory
    # # and store them in the mainContainer
    # # it is a gromacs trajectory
    # mainContainer.initialize_ndarrays()

    # frameIdx = 0

    # if mainContainer.hasGromacsInfo:
    #     coordFactor = FC.UnitsAndConversions.NM2ANG
    #     forceFactor = 0.5/FC.UnitsAndConversions.NM2ANG  #halving forces

    # for iTrajSnapshot in mainContainer.trajSnapshots.iterator():
    #     mainContainer._labCoords[frameIdx] = coordFactor * nmp.reshape(nmp.asarray(iTrajSnapshot.value['coordinates']), (totalAtomPopulation, iTrajSnapshot.value['vectorDim']))
    #     mainContainer._labForces[frameIdx] = forceFactor * nmp.reshape(nmp.asarray(iTrajSnapshot.value['forces']), (totalAtomPopulation, iTrajSnapshot.value['vectorDim']))
    #     frameIdx += 1


    return (myProtein, mainContainer)

#END


