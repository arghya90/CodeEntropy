import optparse 
import re
import sys, os

class AdvancedOptionParser(optparse.OptionParser):
	""" An extended/advanced version of optionParser """
	def __init__(self):
		super().__init__()

	def validate_file(self, arg_filename):
		if os.path.isfile(arg_filename):
			pass
		else:
			raise OSError('File not found', ';', arg_filename)
		return
#END

class OutOfListError(Exception):
	"""Raised when an input value is not in the list of expected values."""
	def __init__(self, arg_varname, arg_value, arg_list):
		self.message = f"{arg_value} is not a valid value for {arg_varname}. It only accepts the following values: "
		for _l in arg_list:
			self.message += f"\n\t{_l}"

		self.message += "\n"

#END


def validate(arg_varname, arg_value, arg_allowed):

	## when checking if a value is in a list 
	if isinstance(arg_allowed) == 'list':
		if arg_value not in arg_allowed:
			raise OutOfListError(arg_varname, arg_value, arg_allowed)


	return
#END


