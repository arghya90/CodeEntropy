""" A class depicting a molecular block which contains info about its atoms and other details """
