""" A module of various classes and data types defined and used in this program """ 

#import all of the package files

from CodeEntropy.FunctionCollection import CustomFunctions
from CodeEntropy.FunctionCollection import EntropyFunctions
from CodeEntropy.FunctionCollection import GeometricFunctions
from CodeEntropy.FunctionCollection import UnitsAndConversions
from CodeEntropy.FunctionCollection import Utils
