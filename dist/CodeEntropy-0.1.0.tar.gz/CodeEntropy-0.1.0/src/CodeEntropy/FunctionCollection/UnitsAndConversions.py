from CodeEntropy.Reader import Constants as CONST

def change_lambda_units(arg_lambdas):
	"""Unit of lambdas : kJ2 mol-2 A-2 amu-1
	change units of lambda to J/s2"""
	# return arg_lambdas * N_AVOGADRO * N_AVOGADRO * AMU2KG * 1e-26
	return arg_lambdas * 1e+29 / CONST.N_AVOGADRO

def get_KT2J(arg_temper):
	"""A temperature dependent KT to Joule conversion"""
	return 4.11e-21 * arg_temper/CONST.DEF_TEMPER


