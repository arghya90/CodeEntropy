""" A module/collection of classes that store information 
about the bonded properties of a molecule. E.g. bonds, angles, dihedrals"""

import numpy as nmp
import sys

from CodeEntropy.FunctionCollection import GeometricFunctions as GF

class Bond(object):
    """ Bond between two atoms (preferably covalent). 
    May serve as a parent of 'contact' """

    def __init__(self, arg_atomIndices2):
        self.atom1, self.atom2 = arg_atomIndices2 # indices of 2 atoms

#END


class Dihedral(object):
    """ Dihedral composed of 4 positions (2 planes with an intersecting line) """

    def __init__(self, arg_atomIndices4, arg_baseMolecule):
        self.atom1, self.atom2, self.atom3, self.atom4 = arg_atomIndices4     # indices of the 4 atoms
        self.atomList = arg_atomIndices4
        self.baseMolecule = arg_baseMolecule

    def __str__(self):
        # return 'Dihedral: {} -> {} -> {} -> {}'.format(self.atom1, self.atom2, self.atom3, self.atom4)
        return 'dihedral List : {} {} {} {}'.format(*self.atomList)


    def __lt__(self, arg_other):
        return sorted(self.atomList[1:3]) < sorted(arg_other.atomList[1:3])

    def __gt__(self, arg_other):
        return sorted(self.atomList[1:3]) > sorted(arg_other.atomList[1:3])

    # def __eq__(self, arg_other):
    #     """ Two dihedrals are deemed equal if their 2,3 atoms are the same """
    #     return sorted(self.atomList[1:3]) == sorted(arg_other.atomList[1:3])
    
    def __hash__(self):
        return hash('{}_{}_{}_{}'.format(*sorted(self.atomList)))


    def is_heavy_dihedral(self):
        """ Based on the information in the base molecule's arrays, see if all the atoms
        in this dihedral are heavy atoms """
        retBool = self.baseMolecule.isHydrogenArray[self.atom1] 
        retBool = retBool or self.baseMolecule.isHydrogenArray[self.atom2] 
        retBool = retBool or self.baseMolecule.isHydrogenArray[self.atom3] 
        retBool = retBool or self.baseMolecule.isHydrogenArray[self.atom4]

        return not retBool
    #END

    def is_BB_dihedral(self):
        """ Based on the information in the base molecule's arrays, see if 2-3 atoms 
        in this dihedral are BB atoms """
        retBool = self.baseMolecule.isBBAtomArray[self.atom2] 
        retBool = retBool and self.baseMolecule.isBBAtomArray[self.atom3] 
        return retBool
    #END

    def is_BB_psi(self):
        """ Checks if a heavy dihedral is BB psi (X-C-----Ca-Y)"""
        if self.is_BB_dihedral():
            if self.baseMolecule.isCAtomArray[self.atom2] and self.baseMolecule.isCaAtomArray[self.atom3]:
                return True
            elif self.baseMolecule.isCAtomArray[self.atom3] and self.baseMolecule.isCaAtomArray[self.atom2]:
                return True
            else:
                return False
        else:
            # if not a BB dihedral, it aint a PHI or PSI
            return False
    #END

    def is_BB_phi(self):
        """ Checks if a heavy dihedral is BB phi (X-Ca-----N-Y)"""
        if self.is_BB_dihedral():
            if self.baseMolecule.isNAtomArray[self.atom2] and self.baseMolecule.isCaAtomArray[self.atom3]:
                return True
            elif self.baseMolecule.isNAtomArray[self.atom3] and self.baseMolecule.isCaAtomArray[self.atom2]:
                return True
            else:
                return False
        else:
            # if not a BB dihedral, it aint a PHI or PSI
            return False
    #END

    def is_from_same_residue(self):
        """ Based on the information in the base molecule's arrays, see if the two central atoms (2,3)
        in this dihedral belong to the same residue. Return the residue index if yes, else -100"""
        if self.baseMolecule.atomResidueIdxArray[self.atom2] ==\
        self.baseMolecule.atomResidueIdxArray[self.atom3]:
            return self.baseMolecule.atomResidueIdxArray[self.atom2]
        else:
            return -10000
    #END

    def get_dihedral_angle_lab(self, arg_dataContainer, arg_frame):
        """ Using the function compute_dihedral in GeometricFunctions module, return the dihedral for this quadruplet in the lab frame"""
        r1 = arg_dataContainer._labCoords[arg_frame][self.atom1]
        r2 = arg_dataContainer._labCoords[arg_frame][self.atom2]
        r3 = arg_dataContainer._labCoords[arg_frame][self.atom3]
        r4 = arg_dataContainer._labCoords[arg_frame][self.atom4]

        return GF.compute_dihedral(r1, r2, r3, r4)
    #END

    def get_dihedral_angle_local(self, arg_dataContainer, arg_frame):
        """ Using the function compute_dihedral in GeometricFunctions module, return the dihedral for this quadruplet in the local frame"""
        r1 = arg_dataContainer.localCoords[arg_frame][self.atom1]
        r2 = arg_dataContainer.localCoords[arg_frame][self.atom2]
        r3 = arg_dataContainer.localCoords[arg_frame][self.atom3]
        r4 = arg_dataContainer.localCoords[arg_frame][self.atom4]

        return GF.compute_dihedral(r1, r2, r3, r4)
    #END

