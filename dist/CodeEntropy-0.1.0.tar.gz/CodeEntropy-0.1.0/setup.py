#!/usr/bin/env python

from setuptools import setup
from setuptools import find_packages

setup(
	## METADATA ##
	name = 'CodeEntropy', 
	author = 'Arghya \"Argo\" Chakravorty', 
	version="0.1.0",
	author_email = 'arghyac@umich.edu',
	description = 'A python package of tools of computing entropy of macromolecular systems from the forces sampled in a MD simulation.',

	## OPTIONS ##
	packages = find_packages('src'),
	package_dir = {'' : 'src'},

	# can be run as a zip
	zip_safe = False,

	# scripts for creating executables
	scripts = ['src/CodeEntropy/mcc_gromacs.py', \
	           'src/CodeEntropy/mcc_charmm.py']

)
