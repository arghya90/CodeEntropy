import optparse 
import re
import sys, os

class AdvancedOptionParser(optparse.OptionParser):
	""" An extended/advanced version of optionParser """
	def __init__(self):
		super().__init__()

	def validate_file(self, arg_filename):
		if os.path.isfile(arg_filename):
			pass
		else:
			raise OSError('File not found', ';', arg_filename)
		return
#END
