import numpy as nmp
from CodeEntropy.Trajectory import (PSFReader, DCDReader)
from CodeEntropy.ClassCollection import DataContainer
from CodeEntropy.FunctionCollection import Utils

########################################################################################################################################
# NOTE: SIGNIFICANT CHANGES IN THE FLOW OF STEPS AND VARIABLE ASSIGNMENT BECAUSE OF THE FUNDAMENTAL DIFFERENCE BETWEEN NAMD AND GROMACS
########################################################################################################################################
def read_charmm_input(arg_psfFile,\
                    arg_xdcdFile, \
                    arg_fdcdFile, \
                    arg_outFile, \
                    arg_beginTime, \
                    arg_endTime, \
                    arg_stride, \
                    arg_verbose = 0 ):
    
    """ 
    Input :
    1. input topology/structure (PSF) 
    2. a coordinate trajectory file from CHARMM (arg_xdcdFile).
    3. a force trajectory file from CHARMM (arg_fdcdFile).

    Separate DCD files are required because unlike GROMACS, CHARMM does
    not print forces in a trajectory. A charmm script to write a FORCE
    trajectory file must be obtianed.
    Function returns an instance of BaseMolecule and 
    DataContainer which are linked to each other.
    """


    # define an object of DataContainer class
    mainContainer = DataContainer.DataContainer()

    # topology/PSF file
    Utils.printflush('{:<40s} : {}'.format('Reading PSF format topology file',arg_psfFile))
    topol = PSFReader.PsfTopology(arg_psfFile, mainContainer)

    # base molecule
    # Unlike the gromacs TPRReader, PSFReader adds bonds
    # and dihedral information in the `read_psfFile` functoin
    # that is called below.
    myProtein = topol.read_psfFile()

    if arg_verbose >= 0:
        Utils.printflush('{:<40s} : {}'.format('Number of atoms expected in trajectory', myProtein.numAtoms))


    # assign host heavy atoms for each hydrogen (needed for entropy calculation at UA level)
    myProtein.hostHeavyAtomArray = nmp.zeros(myProtein.numAtoms)
    for idx in myProtein.bondedHeavyAtomTable.keys():

        if myProtein.isHydrogenArray[idx]:
            # it must have ONE and ONLY ONE heavy atom bonded to it (it host heavy atom)
            try:
                assert(len(myProtein.bondedHeavyAtomTable[idx]) == 1)
            except :
                raise ValueError('Atom {} is a hydrogen with more or less than 1 covalent bonds ({})'.\
                    format(idx, len(myProtein.bondedHeavyAtomTable[idx])))

            # fetch that atom
            try:
                priority, heavyAtomIdx = myProtein.bondedHeavyAtomTable[idx].list_in_order()[0]
                myProtein.hostHeavyAtomArray[idx] = heavyAtomIdx
                myProtein.hostHeavyAtomArray[heavyAtomIdx] = heavyAtomIdx #self
            except:
                raise IndexError('Index {} is out of range'.format(idx))

    # >>> ASSIGN MYPROTEIN TO THE MAIN DATA CONTAINER
    mainContainer.molecule = myProtein


    ### READ DCD TRAJECTORY OF COORDINATES ###
    Utils.printflush('{:<40s} : {}'.format('Reading coordinate trajectory file',arg_xdcdFile))
    crdtraj = DCDReader.DCDTrajectory(arg_fileName=arg_xdcdFile,arg_beginTime=arg_beginTime, arg_endTime=arg_endTime,arg_stride=arg_stride, arg_verbose=arg_verbose)

    ### READ DCD TRAJECTORY OF FORCES ###
    Utils.printflush('{:<40s} : {}'.format('Reading forces trajectory file',arg_fdcdFile))
    frctraj = DCDReader.DCDTrajectory(arg_fileName=arg_fdcdFile,arg_beginTime=arg_beginTime, arg_endTime=arg_endTime,arg_stride=arg_stride, arg_verbose=arg_verbose)

    ### ASSERTION/ VALIDATION ###
    # both trajectories should have the same nu,ber of frames
    try:
        assert(len(crdtraj.snapshots) == len(frctraj.snapshots))
    except:
        raise ValueError("Coordinate and Force trajectory are of different lengths ({} vs {}).".format(len(crdtraj.snapshots), len(frctraj.snapshots)))
    
    # assign the snapshots read in traj to mainContainer's trajSnapshot 
    frameIdx = 0
    for iFrame in crdtraj.snapshots:
        mainContainer.trajSnapshots.append(iFrame)
        mainContainer.frameIndices.append(frameIdx)
        frameIdx += 1

    mainContainer.print_attributes()

    # read the coords and forces from the trajectory
    # and store them in the mainContainer
    mainContainer.initialize_ndarrays()

    coordFactor = 1.0
    forceFactor = 1.0

    frameIdx = 0
    for iTrajSnapshot in crdtraj.snapshots:
        mainContainer._labCoords[frameIdx] = coordFactor * iTrajSnapshot.value['coordinates']
        frameIdx += 1

    frameIdx = 0    
    for fTrajSnapshot in frctraj.snapshots:
        mainContainer._labForces[frameIdx] = forceFactor * fTrajSnapshot.value['coordinates']
        frameIdx += 1


    return (myProtein, mainContainer)

#END


